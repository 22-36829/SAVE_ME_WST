<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

require('../../configs/db.php');

// Fetch the user data from the session or the database
$email = $_SESSION['email'];

// Using prepared statements to prevent SQL injection
$query = "SELECT * FROM User WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Check if the query executed successfully and returned a result
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $userId = $user['user_id']; // Store user ID for later use
    $name = isset($user['name']) ? $user['name'] : 'Unknown User';
    $balance = isset($user['balance']) ? $user['balance'] : 0;

    // Total Savings from Transactions
    $savings_query = "SELECT COALESCE(SUM(st.amount), 0) AS total_savings
                      FROM Savings_Transaction st
                      JOIN Savings s ON st.saving_id = s.saving_id
                      WHERE st.user_id = ? AND st.type = 'add to savings'";
    $savings_stmt = $conn->prepare($savings_query);
    $savings_stmt->bind_param("i", $user['user_id']);
    $savings_stmt->execute();
    $savings_result = $savings_stmt->get_result();
    $total_savings = $savings_result->fetch_assoc()['total_savings'] ?? 0;


    // Fetch total money in and money out
    $money_in_query = "SELECT SUM(amount) AS total_money_in FROM Transaction WHERE user_id = ? AND type = 'money in'";
    $money_in_stmt = $conn->prepare($money_in_query);
    $money_in_stmt->bind_param("i", $userId);
    $money_in_stmt->execute();
    $money_in_result = $money_in_stmt->get_result();
    $total_money_in = $money_in_result->fetch_assoc()['total_money_in'] ?? 0;

    $money_out_query = "SELECT SUM(amount) AS total_money_out FROM Transaction WHERE user_id = ? AND type = 'money out'";
    $money_out_stmt = $conn->prepare($money_out_query);
    $money_out_stmt->bind_param("i", $userId);
    $money_out_stmt->execute();
    $money_out_result = $money_out_stmt->get_result();
    $total_money_out = $money_out_result->fetch_assoc()['total_money_out'] ?? 0;

} else { 
    header('Location: ../login.php?msg=User not found');
    exit;
}

// Process transaction form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = floatval($_POST['amount']);
    $description = trim($_POST['description']);
    $type = $_POST['type'];

    // Validate the input
    if ($amount <= 0) {
        die("The amount must be greater than zero.");
    }
    if (empty($description)) {
        die("Description cannot be empty.");
    }

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Insert into the Transaction table
        $insertTransaction = $conn->prepare("
            INSERT INTO Transaction (user_id, amount, type, description)
            VALUES (?, ?, ?, ?)
        ");
        $insertTransaction->bind_param("idss", $userId, $amount, $type, $description);
        $insertTransaction->execute();

        // Update the User balance based on transaction type
        if ($type === 'money in') {
            // Increase balance for money in
            $updateBalance = $conn->prepare("
                UPDATE User
                SET balance = balance + ?
                WHERE user_id = ?
            ");
            $updateBalance->bind_param("di", $amount, $userId);
        } else if ($type === 'money out') {
            // Check if user has enough balance for the transaction
            $balanceQuery = $conn->prepare("SELECT balance FROM User WHERE user_id = ?");
            $balanceQuery->bind_param("i", $userId);
            $balanceQuery->execute();
            $result = $balanceQuery->get_result();
            $currentBalance = $result->fetch_assoc()['balance'];

            if ($amount > $currentBalance) {
                die("Insufficient balance for this transaction.");
            }

            // Decrease balance for money out
            $updateBalance = $conn->prepare("
                UPDATE User
                SET balance = balance - ?
                WHERE user_id = ?
            ");
            $updateBalance->bind_param("di", $amount, $userId);
        }

        // Execute the balance update
        $updateBalance->execute();

        // Commit the transaction
        $conn->commit();

        // Output success message and trigger page reload
        echo "<script>
                alert('Balance updated successfully!');
                window.location.href = 'balance.php';
              </script>";
        exit;

    } catch (Exception $e) {
        // Rollback the transaction if something failed
        $conn->rollback();
        echo "Failed: " . $e->getMessage();
    }
}

// Fetch recent transactions
$transaction_query = "
    SELECT * FROM Transaction 
    WHERE user_id = ? 
    ORDER BY transaction_date DESC 
    LIMIT 7";
$transaction_stmt = $conn->prepare($transaction_query);
$transaction_stmt->bind_param("i", $userId);
$transaction_stmt->execute();
$transaction_result = $transaction_stmt->get_result();
$transactions = $transaction_result->fetch_all(MYSQLI_ASSOC);



// Initialize filter variables
$searchDescription = isset($_GET['search_description']) ? $_GET['search_description'] : '';
$searchAmount = isset($_GET['search_amount']) ? $_GET['search_amount'] : '';
$createdDate = isset($_GET['created_date']) ? $_GET['created_date'] : '';
$transactionType = isset($_GET['transaction_type']) ? $_GET['transaction_type'] : '';

// Start the SQL query
$transaction_query = "SELECT * FROM Transaction WHERE user_id = ?";

// Array to store filter conditions
$filterParams = [$userId];

// Add filters dynamically to the query
if (!empty($searchDescription)) {
    $transaction_query .= " AND description LIKE ?";
    $filterParams[] = '%' . $searchDescription . '%'; // Wildcard search for description
}

if (!empty($searchAmount)) {
    $transaction_query .= " AND amount = ?";
    $filterParams[] = $searchAmount; // Exact match for amount
}

if (!empty($createdDate)) {
    $transaction_query .= " AND DATE(transaction_date) = ?";
    $filterParams[] = $createdDate; // Filter by specific date
}

if (!empty($transactionType)) {
    $transaction_query .= " AND type = ?";
    $filterParams[] = $transactionType; // Filter by transaction type (money in or money out)
}

// Order by date and limit results
$transaction_query .= " ORDER BY transaction_date DESC LIMIT 7";

// Prepare and execute the query
$transaction_stmt = $conn->prepare($transaction_query);
$transaction_stmt->bind_param(str_repeat('s', count($filterParams)), ...$filterParams); // Dynamically bind the params
$transaction_stmt->execute();
$transaction_result = $transaction_stmt->get_result();
$transactions = $transaction_result->fetch_all(MYSQLI_ASSOC);

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../assets/img/logo.png" type="image/x-icon">
    <title>Balance | Save ME</title>
   
    <link rel="stylesheet" href="./css/all.min.css" />
    <link rel="stylesheet" href="../user_dashboard/css/common.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    

  

</head>

<body>
<div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="balance.php">
                        <i class="fas fa-wallet" style="margin-right: 8px;"></i><span>Balance</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="savings.php">
                        <i class="fas fa-piggy-bank" style="margin-right: 8px;"></i><span>Savings</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reports_analytics.php">
                        <i class="fas fa-chart-line" style="margin-right: 8px;"></i><span>Reports and Analytics</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="support.php">
                        <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar-alt" style="margin-right: 8px;"></i><span>Schedule</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../scripts/logout.php">
                        <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>


    <!-- Top Navigation -->
    <div class="navbar-top">
       
    <div class="navbar-buttons" >
            <button class="dropdown-btn"><img src="../img/bell.png" alt="Alerts" style="width: 16px; height: 16px;" ></button>
            <button class="dropdown-btn"><img src="../img/envelope.png" alt="Notifications" style="width: 16px; height: 16px;"></button>
           <button class="dropdown-btn"><img src="../img/user.png" alt="Profile"style="width: 16px; height: 16px; padding-right:40px;"></button>
        </div>
    </div>




    <!-- Main Content -->
    <div class="main-content">
        <div class="welcome-header">
            <h3>Track Your Balance Here, <?php echo $name; ?></h3>
        </div>

        <div class="search-date">
    <form method="GET" action="">
        <!-- Search by Description -->
        <label for="search_description">Search Description:</label>
        <input type="text" class="search-name" id="search_description" name="search_description" value="<?php echo htmlspecialchars($searchDescription); ?>" placeholder="Enter description...">

        <!-- Search by Amount -->
        <label for="search_amount">Search Amount (₱):</label>
        <input type="number" class="search-name" id="search_amount" name="search_amount" value="<?php echo htmlspecialchars($searchAmount); ?>" placeholder="Enter amount...">

        <!-- Search by Created Date -->
        <label for="created_date">Created Date:</label>
        <input type="date" class="search-date" id="created_date" name="created_date" value="<?php echo htmlspecialchars($createdDate); ?>">

        <!-- Dropdown for Money Type (Money In or Money Out) -->
        <label for="transaction_type">Transaction Type:</label>
        <select name="transaction_type" class="search-name" id="transaction_type">
            <option value="">All</option>
            <option value="money in" <?php if (isset($_GET['transaction_type']) && $_GET['transaction_type'] == 'money in') echo 'selected'; ?>>Money In</option>
            <option value="money out" <?php if (isset($_GET['transaction_type']) && $_GET['transaction_type'] == 'money out') echo 'selected'; ?>>Money Out</option>
        </select>
        
        <input type="submit" value="Search" class="btn-search">
        <a href="balance.php" class="btn-reset">Reset</a>
    </form>
</div>


        <div class="income-inf-row">
        <div class="col-income">
            <div class="card balance-card">
                <div class="card-body">
                    <div class="card-span">Balance</div>
                    <div class="card-price">₱ <?php echo number_format($balance); ?></div>
                    
                    <!-- Button container for + and - buttons -->
                    <div class="button-container">
                        <button onclick="openModal('moneyIn')" class="flaticon-button">
                            <i class="fas fa-plus-circle"></i>
                        </button>
                        <button onclick="openModal('moneyOut')" class="flaticon-button">
                            <i class="fas fa-minus-circle"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

             <!-- Income Information Row with Money In and Out Icons -->
        <div class="income-inf-row">
            <div class="col-income">
                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            <div class="card-span">Money In</div>
                            <div class="card-price">₱ <?php echo number_format($total_money_in); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-income">
                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            <div class="card-span">Money Out</div>
                            <div class="card-price">₱ <?php echo number_format($total_money_out); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-income">
                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            <div class="card-span">Total Savings</div>
                            <div class="card-price">₱ <?php echo number_format($total_savings, 2); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

     


    </div>
    <div class="overview-row">
            <div class="recent-transactions">
                <div class="earning-header">
                    <h6>Transactions</h6>
                   
                </div>
                <div class="earning-body">
                    <table class="transaction-table">
                        <thead>
                            <tr>
                                <th>Amount</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td>₱ <?php echo number_format($transaction['amount']); ?></td>
                                    <td><?php echo ucfirst($transaction['type']); ?></td>
                                    <td><?php echo htmlspecialchars($transaction['description']); ?></td>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($transaction['transaction_date'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>    
</div>
</div>

       <!-- Transaction Modal -->
       <div id="transactionModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h4 id="modalTitle"></h4>
            <button class="close-btn" onclick="closeModal()">×</button>
        </div>
        <form action="balance.php" method="POST">
            <input type="hidden" id="transactionType" name="type" value="">
            <div class="input-group">
                <label for="amount">Amount</label>
                <input type="number" id="amount" name="amount" required>
            </div>
            <div class="input-group">
                <label for="description">Description</label>
                <input type="text" id="description" name="description" required>
            </div>
            <button type="submit" class="button-submit">Submit</button>
        </form>
    </div>
</div>

<script>
    // Open the modal and set the transaction type (Money In or Money Out)
    function openModal(type) {
        document.getElementById("transactionModal").style.display = "flex";
        document.getElementById("transactionType").value = (type === "moneyIn") ? "money in" : "money out";
        document.getElementById("modalTitle").innerText = (type === "moneyIn") ? "Add Money In" : "Add Money Out";
    }

    // Close the modal
    function closeModal() {
        document.getElementById("transactionModal").style.display = "none";
    }

    // Close the modal if clicked outside
    window.onclick = function(event) {
        let modal = document.getElementById("transactionModal");
        if (event.target === modal) {
            closeModal();
        }
    };
</script>
</body>
</html>
