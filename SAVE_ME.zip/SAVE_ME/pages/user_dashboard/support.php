<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

require('../../configs/db.php');

$email = $_SESSION['email'];

// Fetch the user data from the session or the database
$query = "SELECT * FROM User WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $user_id = $user['user_id'];
    $name = $user['name'] ?? 'User';
} else {
    header('Location: ../login.php?msg=User not found');
    exit;
}

// Check for POST request and handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['support_message'])) {
    $concern = trim($_POST['support_message']);

    if (!empty($concern)) {
        // Prepare the INSERT query for the Support table
        $query = "INSERT INTO Support (user_id, concern, created_at) VALUES (?, ?, NOW())";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("is", $user_id, $concern);

        if ($stmt->execute()) {
            $_SESSION['success_msg'] = "Your concern has been submitted successfully.";
            // Redirect to prevent form resubmission
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit;
        } else {
            $_SESSION['error_msg'] = "Error submitting your concern. Please try again.";
        }

        $stmt->close();
    } else {
        $_SESSION['error_msg'] = "Please enter a concern before submitting.";
    }
}

// Initialize search variables (from GET request)
$searchTitle = $_GET['search_title'] ?? '';
$filterDate = $_GET['created_at'] ?? '';
$statusFilter = $_GET['status'] ?? '';

// Build the query with dynamic filters
$support_query = "SELECT * FROM Support WHERE user_id = ?";
$params = [$user_id];
$types = "i";  // Always bind the user_id as integer

// Add search criteria for "concern" field if specified
if (!empty($searchTitle)) {
    $support_query .= " AND concern LIKE ?";
    $params[] = '%' . $searchTitle . '%'; // Add the LIKE pattern for search
    $types .= "s"; // Append 's' for string parameter
}

// Add date filter if specified
if (!empty($filterDate)) {
    $support_query .= " AND DATE(created_at) = ?";
    $params[] = $filterDate;  // Date string
    $types .= "s"; // Append 's' for string parameter
}

// Add status filter if specified (Pending or Replied)
if (!empty($statusFilter)) {
    if ($statusFilter == 'Pending') {
        $support_query .= " AND admin_reply IS NULL";
    } elseif ($statusFilter == 'Replied') {
        $support_query .= " AND admin_reply IS NOT NULL";
    }
}

// Prepare and execute the query
$support_stmt = $conn->prepare($support_query);
$support_stmt->bind_param($types, ...$params);
$support_stmt->execute();
$support_result = $support_stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../assets/img/logo.png" type="image/x-icon">
    <title>Support | Save ME</title>
    <link rel="stylesheet" href="./css/all.min.css" />
    <link rel="stylesheet" href="../user_dashboard/css/common.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .support-header { font-size: 20px; font-weight: bold; color: #5B845C; }
        .support-textarea { width: 100%; height: 100px; padding: 10px; margin-top: 10px; background-color: #E6F4D8; border: 1px solid #B5D8A4; border-radius: 5px; }
        .submit-btn { background-color: #A3D77C; border: none; color: #fff; padding: 10px 20px; cursor: pointer; border-radius: 5px; margin-top: 10px; }
        .controls { display: flex; gap: 10px; margin-top: 20px; }
        .controls input, .controls select { padding: 10px; border: 1px solid #B5D8A4; border-radius: 5px; }
        .controls .btn { padding: 10px 20px; background-color: #9FC490; border: none; color: white; cursor: pointer; border-radius: 5px; }
        .controls .reset { background-color: #B5D8A4; }
        .transaction-table { width: 100%; margin-top: 20px; border-collapse: collapse; }
        .transaction-table th, .transaction-table td { padding: 10px; border: 1px solid #D4E9C6; text-align: left; }
        .transaction-table th { background-color: #CFE3BC; color: #fff; }
    </style>
    <script>
        // Display success or error message if set in the session
        <?php if (isset($_SESSION['success_msg'])): ?>
            alert("<?php echo $_SESSION['success_msg']; ?>");
            <?php unset($_SESSION['success_msg']); ?>
        <?php elseif (isset($_SESSION['error_msg'])): ?>
            alert("<?php echo $_SESSION['error_msg']; ?>");
            <?php unset($_SESSION['error_msg']); ?>
        <?php endif; ?>
    </script>
</head>
<body>
<div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="balance.php">
                        <i class="fas fa-wallet" style="margin-right: 8px;"></i><span>Balance</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="savings.php">
                        <i class="fas fa-piggy-bank" style="margin-right: 8px;"></i><span>Savings</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reports_analytics.php">
                        <i class="fas fa-chart-line" style="margin-right: 8px;"></i><span>Reports and Analytics</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="support.php">
                        <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar-alt" style="margin-right: 8px;"></i><span>Schedule</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../scripts/logout.php">
                        <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>


    <!-- Top Navigation -->
    <div class="navbar-top">
       
    <div class="navbar-buttons" >
            <button class="dropdown-btn"><img src="../img/bell.png" alt="Alerts" style="width: 16px; height: 16px;" ></button>
            <button class="dropdown-btn"><img src="../img/envelope.png" alt="Notifications" style="width: 16px; height: 16px;"></button>
           <button class="dropdown-btn"><img src="../img/user.png" alt="Profile"style="width: 16px; height: 16px; padding-right:40px;"></button>
        </div>
    </div>

        <div class="main-content">
            <div class="welcome-header">
                <h3>Welcome, <?php echo htmlspecialchars($name); ?></h3>
            </div>

            <div class="concernTxtBox">
                <form method="POST" action="">
                    <textarea name="support_message" class="support-textarea" placeholder="Type here..."></textarea>
                    <button type="submit" class="submit-btn">Submit</button>
                </form>
            </div>

            <div class="controls">
                <form method="GET" action="support.php">
                    <input type="text" name="search_title" placeholder="Search by concern..." value="<?php echo htmlspecialchars($searchTitle); ?>">
                    <input type="date" name="created_at" value="<?php echo htmlspecialchars($filterDate); ?>">
                    <select name="status">
                        <option value="">All Statuses</option>
                        <option value="Pending" <?php echo $statusFilter === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="Replied" <?php echo $statusFilter === 'Replied' ? 'selected' : ''; ?>>Replied</option>
                    </select>
                    <button type="submit" class="btn search">Search</button>
                    <button type="button" class="btn reset" onclick="window.location.href='support.php'">Reset</button>
                </form>
            </div>

            <div class="overview-row">
                <div class="recent-transactions">
                    <div class="earning-header">
                        <h6>Transactions</h6>
                    </div>
                    <div class="earning-body">
                        <table class="transaction-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Concern</th>
                                    <th>Created Date</th>
                                    <th>Admin Reply</th>
                                    <th>Replied Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $support_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['support_id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['concern']); ?></td>
                                        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                                        <td><?php echo htmlspecialchars($row['admin_reply'] ?? 'Pending'); ?></td>
                                        <td><?php echo htmlspecialchars($row['reply_at'] ?? 'Pending'); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
