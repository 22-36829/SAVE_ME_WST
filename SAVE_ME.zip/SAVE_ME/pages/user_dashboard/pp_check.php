<?php
// pp_check.php

// Perform any checks needed for the user session or permissions
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php?msg=Access denied. Please log in.');
    exit;
}

// You can add other checks as needed
?>
