<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="./css/all.min.css" />
    <link rel="stylesheet" href="../user_dashboard/css/common.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* Container adjustments */
        .container {
            display: flex;
            background-color: transparent;
        }

        /* Main content styles */
        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: tran;
            font-family: Arial, sans-serif;
            margin-left: 300px; /* Adjust for sidebar width */
            margin-top: 100px; /* Adjust for top navbar */
            box-sizing: border-box;
        }

        /* Profile Card */
        .profile-card {
            display: flex;
            align-items: center;
            background-color: #f4f6ec;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            position: relative;
        }
        .profile-card img {
            width: 100px;
            height: 100px;
            background-color: #c1d1b5;
            border-radius: 8px;
            margin-right: 20px;
        }
        .upload-btn {
            display: block;
            margin-top: 10px;
            padding: 5px 10px;
            background-color: #8cb082;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .profile-info {
            flex-grow: 1;
            padding-right: 20px;
        }
        .profile-info p {
            margin: 5px 0;
            font-size: 1em;
        }
        .profile-info p strong {
            font-weight: bold;
        }
        .profile-actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: flex-start;
        }
        .profile-actions button {
            width: 150px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            text-align: left;
            padding-left: 15px;
        }
        .edit-btn {
            background-color: #8cb082;
            color: white;
        }
        .reset-btn {
            background-color: #f0ad4e;
            color: white;
        }
        .delete-btn {
            background-color: #d9534f;
            color: white;
        }

        /* Sections */
        .section {
            background-color: #d3e2c8;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .form-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            align-items: center;
        }
        .form-row input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 0.9em;
        }
        .form-row .third-width {
            width: calc(33.33% - 10px);
        }
        .form-row .otp-input {
            width: calc(35% - 5px); /* Slightly increased width for OTP placeholders */
        }
        .verify-btn {
            background-color: #5bc0de;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            width: 80px;
            margin-left: 5px;
        }
        .save-btn {
            padding: 10px 20px;
            border: none;
            background-color: #8cb082;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            width: 100px;
            margin-top: 10px;
            align-self: flex-end;
        }
        .checkbox-container {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        .checkbox-container input[type="checkbox"] {
            margin-right: 5px;
        }
    </style>
</head>

<body>

<div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="balance.php">
                        <i class="fas fa-wallet" style="margin-right: 8px;"></i><span>Balance</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="savings.php">
                        <i class="fas fa-piggy-bank" style="margin-right: 8px;"></i><span>Savings</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reports_analytics.php">
                        <i class="fas fa-chart-line" style="margin-right: 8px;"></i><span>Reports and Analytics</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="support.php">
                        <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar-alt" style="margin-right: 8px;"></i><span>Schedule</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../scripts/logout.php">
                        <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                    </a>
                </li>
            </ul>
        </div>

    <!-- Top Navigation -->
    <div class="navbar-top">
        <div class="navbar-buttons">
            <button class="dropdown-btn"><img src="../img/bell.png" alt="Alerts" style="width: 16px; height: 16px;"></button>
            <button class="dropdown-btn"><img src="../img/envelope.png" alt="Notifications" style="width: 16px; height: 16px;"></button>
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile" style="width: 16px; height: 16px; padding-right:40px;"></button>
        </div>
    </div>
</div>

<div class="main-content">
    <!-- Profile Card Section -->
    <div class="profile-card">
        <img src="../img/profile-placeholder.png" alt="Profile Picture">
        <div class="profile-info">
            <p><strong>Full Name:</strong> [Full Name]</p>
            <p><strong>Email:</strong> [Email]</p>
            <p><strong>Mobile Number:</strong> [Mobile Number]</p>
            <p><strong>Account Created Date:</strong> [Account Created Date]</p>
            <p><strong>Status:</strong> [Status]</p>
            <button class="upload-btn">Upload</button>
        </div>
        <div class="profile-actions">
            <button class="edit-btn">Edit Profile</button>
            <button class="reset-btn">Reset Password</button>
            <button class="delete-btn">Delete Account</button>
        </div>
    </div>

    <!-- Set New Password Section -->
    <div class="section">
        <div class="section-title">Set New Password</div>
        <div class="form-row">
            <input type="password" class="third-width" placeholder="Old Password">
            <input type="text" class="third-width" placeholder="Phone Number">
            <div style="display: flex; align-items: center;">
                <input type="text" class="otp-input" placeholder="SMS OTP Pin">
                <button class="verify-btn">Verify</button>
            </div>
        </div>
        <div class="form-row">
            <input type="password" class="third-width" placeholder="New Password">
            <input type="email" class="third-width" placeholder="Email">
            <div style="display: flex; align-items: center;">
                <input type="text" class="otp-input" placeholder="Email OTP Pin">
                <button class="verify-btn">Verify</button>
            </div>
        </div>
        <div class="form-row">
            <input type="password" class="third-width" placeholder="Confirm Password">
            <button class="save-btn">Save</button>
        </div>
    </div>

    <!-- Edit Information Section -->
    <div class="section">
        <div class="section-title">Edit Information</div>
        <div class="form-row">
            <input type="text" class="third-width" placeholder="Full Name">
            <input type="text" class="third-width" placeholder="Edit Full Name">
            <div style="display: flex; align-items: center;">
                <input type="text" class="otp-input" placeholder="Password">
                <button class="verify-btn">Verify</button>
            </div>
        </div>
        <div class="form-row">
            <input type="email" class="third-width" placeholder="Email">
            <input type="email" class="third-width" placeholder="Edit Email">
            <div style="display: flex; align-items: center;">
                <input type="text" class="otp-input" placeholder="Email OTP Pin">
                <button class="verify-btn">Verify</button>
            </div>
        </div>
        <div class="form-row">
            <input type="text" class="third-width" placeholder="Number">
            <input type="text" class="third-width" placeholder="Edit Number">
            <div class="checkbox-container">
                <input type="checkbox" id="confirm-info">
                <label for="confirm-info">Confirm info</label>
            </div>
            <button class="save-btn">Save</button>
        </div>
    </div>
</div>

</body>
</html>
