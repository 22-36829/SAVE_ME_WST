<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

require('../../configs/db.php');

// Get User Details
$email = $_SESSION['email'];
$query = "SELECT * FROM User WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $_SESSION['user_id'] = $user['user_id'];
    $name = $user['name'] ?? 'Unknown User';
    $balance = $user['balance'] ?? 0;

    // Handle form submission to insert a new savings goal
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'add_savings') {
        $title = $_POST['title'];
        $amount = $_POST['amount'];
        $deadline_date = $_POST['deadline_date'];
        $description = $_POST['description'];
        
        // Insert new savings goal
        $insert_query = "INSERT INTO Savings (user_id, title, amount, description, deadline_date, status) VALUES (?, ?, ?, ?, ?, 'in progress')";
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->bind_param("isdss", $user['user_id'], $title, $amount, $description, $deadline_date);
        
        if ($insert_stmt->execute()) {
            echo "<p>New savings goal created successfully!</p>";
        } else {
            echo "<p>Error: Could not create savings goal.</p>";
        }
    }

    // Handle form submission to add a transaction for a savings goal
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'edit_savings') {
        $saving_id = $_POST['saving_id'];
        $transaction_amount = $_POST['amount'];
        $transaction_type = $_POST['type'];
        $transaction_description = $_POST['description'];

        // Check if balance is sufficient
        if ($balance >= $transaction_amount) {
            // Deduct amount from user balance
            $new_balance = $balance - $transaction_amount;
            $update_balance_query = "UPDATE User SET balance = ? WHERE user_id = ?";
            $update_balance_stmt = $conn->prepare($update_balance_query);
            $update_balance_stmt->bind_param("di", $new_balance, $user['user_id']);

            if ($update_balance_stmt->execute()) {
                // Insert transaction for the specified savings goal
                $transaction_query = "INSERT INTO Savings_Transaction (saving_id, user_id, amount, type, description) VALUES (?, ?, ?, ?, ?)";
                $transaction_stmt = $conn->prepare($transaction_query);
                $transaction_stmt->bind_param("iisss", $saving_id, $user['user_id'], $transaction_amount, $transaction_type, $transaction_description);

                if ($transaction_stmt->execute()) {
                    echo "<p>Transaction added successfully and balance updated!</p>";
                    $balance = $new_balance; // Update balance in session
                } else {
                    echo "<p>Error: Could not add transaction.</p>";
                }
            } else {
                echo "<p>Error: Could not update balance.</p>";
            }
        } else {
            echo "<p>Not enough balance to complete this transaction.</p>";
        }
    }

    // Handle form submission to delete a savings goal and its transactions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'delete_savings') {
        $saving_id = $_POST['saving_id'];

        // Retrieve all transactions for this savings goal to refund the amounts
        $get_transactions_query = "SELECT amount FROM Savings_Transaction WHERE saving_id = ?";
        $get_transactions_stmt = $conn->prepare($get_transactions_query);
        $get_transactions_stmt->bind_param("i", $saving_id);
        $get_transactions_stmt->execute();
        $transactions_result = $get_transactions_stmt->get_result();

        // Calculate total refund amount
        $total_refund = 0;
        while ($transaction = $transactions_result->fetch_assoc()) {
            $total_refund += $transaction['amount'];
        }

        // Refund the total amount back to user's balance
        $new_balance = $balance + $total_refund;
        $update_balance_query = "UPDATE User SET balance = ? WHERE user_id = ?";
        $update_balance_stmt = $conn->prepare($update_balance_query);
        $update_balance_stmt->bind_param("di", $new_balance, $user['user_id']);
        $update_balance_stmt->execute();

        // Delete associated transactions first due to foreign key constraints
        $delete_transactions_query = "DELETE FROM Savings_Transaction WHERE saving_id = ?";
        $delete_transactions_stmt = $conn->prepare($delete_transactions_query);
        $delete_transactions_stmt->bind_param("i", $saving_id);
        $delete_transactions_stmt->execute();

        // Delete the savings goal
        $delete_goal_query = "DELETE FROM Savings WHERE saving_id = ?";
        $delete_goal_stmt = $conn->prepare($delete_goal_query);
        $delete_goal_stmt->bind_param("i", $saving_id);

        if ($delete_goal_stmt->execute()) {
            echo "<p>Savings goal and related transactions deleted successfully! Balance has been refunded.</p>";
            $balance = $new_balance; // Update balance in session
        } else {
            echo "<p>Error: Could not delete savings goal.</p>";
        }
    }

    // Total Savings from Transactions
    $savings_query = "SELECT COALESCE(SUM(st.amount), 0) AS total_savings
                      FROM Savings_Transaction st
                      JOIN Savings s ON st.saving_id = s.saving_id
                      WHERE st.user_id = ? AND st.type = 'add to savings'";
    $savings_stmt = $conn->prepare($savings_query);
    $savings_stmt->bind_param("i", $user['user_id']);
    $savings_stmt->execute();
    $savings_result = $savings_stmt->get_result();
    $total_savings = $savings_result->fetch_assoc()['total_savings'] ?? 0;

    // In-Progress Goals
    $in_progress_query = "SELECT COUNT(*) AS in_progress FROM Savings WHERE user_id = ? AND status = 'in progress'";
    $in_progress_stmt = $conn->prepare($in_progress_query);
    $in_progress_stmt->bind_param("i", $user['user_id']);
    $in_progress_stmt->execute();
    $in_progress_result = $in_progress_stmt->get_result();
    $in_progress_goals = $in_progress_result->fetch_assoc()['in_progress'] ?? 0;

    // Completed Goals
    $completed_goals_query = "SELECT COUNT(*) AS completed FROM Savings WHERE user_id = ? AND status = 'completed'";
    $completed_goals_stmt = $conn->prepare($completed_goals_query);
    $completed_goals_stmt->bind_param("i", $user['user_id']);
    $completed_goals_stmt->execute();
    $completed_goals_result = $completed_goals_stmt->get_result();
    $completed_goals = $completed_goals_result->fetch_assoc()['completed'] ?? 0;

    // Set up filtering conditions based on input values
    $searchTitle = $_GET['search_title'] ?? '';
    $filterStatus = $_GET['status_filter'] ?? '';
    $filterDate = $_GET['created_at'] ?? '';

    // Base query for goals, with deadline_date instead of duration
    $goal_query = "SELECT s.saving_id, s.title, s.amount, s.deadline_date, s.status,
                   COALESCE(SUM(st.amount), 0) AS amount_saved
                   FROM Savings s
                   LEFT JOIN Savings_Transaction st ON s.saving_id = st.saving_id AND st.type = 'add to savings'
                   WHERE s.user_id = ?";

    // Initialize the parameters array for binding
    $params = ["i", $user['user_id']];

    // Add conditions based on the filter values
    if (!empty($searchTitle)) {
        $goal_query .= " AND (s.title LIKE ? OR s.description LIKE ?)";
        $params[0] .= "ss";
        $params[] = "%$searchTitle%";
        $params[] = "%$searchTitle%";
    }
    if (!empty($filterDate)) {
        $goal_query .= " AND DATE(s.created_at) = ?";
        $params[0] .= "s";
        $params[] = $filterDate;
    }
    if (!empty($filterStatus)) {
        $goal_query .= " AND s.status = ?";
        $params[0] .= "s";
        $params[] = $filterStatus;
    }

    $goal_query .= " GROUP BY s.saving_id";

    // Prepare statement with the dynamically built query
    $goal_stmt = $conn->prepare($goal_query);

    // Bind parameters dynamically
    $goal_stmt->bind_param(...$params);

    $goal_stmt->execute();
    $goal_result = $goal_stmt->get_result();
    $goals = $goal_result->fetch_all(MYSQLI_ASSOC);

    // Fetch All Savings Transactions for the Current User
    $savings_transactions = [];
    $savings_transactions_query = "SELECT * FROM Savings_Transaction WHERE user_id = ? ORDER BY transaction_date DESC";
    $savings_transactions_stmt = $conn->prepare($savings_transactions_query);
    $savings_transactions_stmt->bind_param("i", $user['user_id']);
    if ($savings_transactions_stmt->execute()) {
        $savings_transactions_result = $savings_transactions_stmt->get_result();
        $savings_transactions = $savings_transactions_result->fetch_all(MYSQLI_ASSOC);
    }
} else {
    header('Location: ../login.php?msg=User not found');
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Savings</title>
    <link rel="stylesheet" href="sample/style.css">
    <link rel="stylesheet" href="./css/all.min.css" />
    <link rel="stylesheet" href="../user_dashboard/css/common.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Modal styling */
        .modal { display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0, 0, 0, 0.5); justify-content: center; align-items: center; }
        .modal-content { background-color: #fefefe; padding: 20px; border-radius: 8px; width: 400px; max-width: 90%; text-align: center; }
        .modal-close { float: right; cursor: pointer; font-size: 20px; }
    </style>
</head>
<body>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                   
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="balance.php">
                        <i class="fas fa-wallet" style="margin-right: 8px;"></i><span>Balance</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="savings.php">
                        <i class="fas fa-piggy-bank" style="margin-right: 8px;"></i><span>Savings</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reports_analytics.php">
                        <i class="fas fa-chart-line" style="margin-right: 8px;"></i><span>Reports and Analytics</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="support.php">
                        <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar-alt" style="margin-right: 8px;"></i><span>Schedule</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../scripts/logout.php">
                        <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

       <!-- Top Navigation -->
       <div class="navbar-top">
       
       <div class="navbar-buttons" >
               <button class="dropdown-btn"><img src="../img/bell.png" alt="Alerts" style="width: 16px; height: 16px;" ></button>
               <button class="dropdown-btn"><img src="../img/envelope.png" alt="Notifications" style="width: 16px; height: 16px;"></button>
               <button class="dropdown-btn"><img src="../img/user.png" alt="Profile"style="width: 16px; height: 16px; padding-right:40px;"></button>
           </div>
       </div>
   

<!-- Main content -->
<main class="main-content">
    <div class="dashboard">
        <h1>Save and Set Goals Here, <?php echo htmlspecialchars($name); ?></h1>

        <!-- Stats cards -->
        <div class="stats">
            <div class="stat-card"><h2>Balance</h2><p>₱ <?php echo number_format($balance, 2); ?></p></div>
            <div class="stat-card"><h2>Total Savings</h2><p>₱ <?php echo number_format($total_savings, 2); ?></p></div>
            <div class="stat-card"><h2>Current Goals</h2><p><?php echo $in_progress_goals; ?> In Progress</p></div>
            <div class="stat-card"><h2>Done Goals</h2><p><?php echo $completed_goals; ?></p></div>
        </div>

        <div class="controls">
            <form method="GET" action="savings.php">
                <input type="text" name="search_title" placeholder="Search goals..." value="<?php echo htmlspecialchars($searchTitle); ?>">
                <input type="date" class="search-date" name="created_at" value="<?php echo htmlspecialchars($filterDate); ?>">

                <select name="status_filter">
                    <option value="">All</option>
                    <option value="in progress" <?php if ($filterStatus === 'in progress') echo 'selected'; ?>>In Progress</option>
                    <option value="completed" <?php if ($filterStatus === 'completed') echo 'selected'; ?>>Done</option>
                </select>

                <button type="submit" class="btn search">Search</button>
                <button type="button" class="btn reset" onclick="window.location.href='savings.php'">Reset</button>
            </form>
        </div>

<!-- Goals Section -->
<div class="goals">
    <?php foreach ($goals as $goal): ?>
        <div class="goal">
            <div class="goal-header">
                <h3><?php echo htmlspecialchars($goal['title']); ?></h3>
                <div class="icons">
                    <button class="edit-btn" onclick="openEditModal(<?php echo $goal['saving_id']; ?>)"><i class="fas fa-edit"></i></button>
                    <button class="delete-btn" onclick="openDeleteModal(<?php echo $goal['saving_id']; ?>)"><i class="fas fa-trash-alt"></i></button>
                </div>
            </div>
            <p>Target Amount: ₱ <?php echo number_format($goal['amount'], 2); ?></p>
            <p>Deadline: <?php echo htmlspecialchars(date("F j, Y", strtotime($goal['deadline_date']))); ?></p>
            <p>Progress: ₱ <?php echo number_format($goal['amount_saved'], 2); ?> / ₱ <?php echo number_format($goal['amount'], 2); ?></p>
            <div class="progress-bar">
                <div class="progress" style="width: <?php echo min(($goal['amount_saved'] / $goal['amount']) * 100, 100); ?>%;"></div>
            </div>
        </div>
    <?php endforeach; ?>
    <div class="add-goal">
        <button class="add-btn" onclick="openModal('addSavingsModal')">+</button>
    </div>
</div>

        <!-- All Savings Transactions Table -->
            <div class="overview-row">
                <div class="recent-transactions">
                    <div class="earning-header"><h6>All Savings Transactions</h6></div>
                    <div class="earning-body">
                        <table class="transaction-table">
                            <thead>
                                <tr>
                                    <th>Amount</th>
                                    <th>Type</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($savings_transactions)): ?>
                                    <?php foreach ($savings_transactions as $transaction): ?>
                                        <tr>
                                            <td>₱ <?php echo number_format($transaction['amount'], 2); ?></td>
                                            <td><?php echo ucfirst($transaction['type']); ?></td>
                                            <td><?php echo htmlspecialchars($transaction['description']); ?></td>
                                            <td><?php echo date('Y-m-d H:i:s', strtotime($transaction['transaction_date'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4">No savings transactions available.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</main>
</div>

<!-- Modals -->
<div id="addSavingsModal" class="modal">
    <div class="modal-content">
        <span class="modal-close" onclick="closeModal('addSavingsModal')">&times;</span>
        <h2>Create New Savings Goal</h2>
        <form id="addSavingsForm" method="post" action="">
            <input type="hidden" name="action" value="add_savings">
            <input type="text" name="title" placeholder="Goal Title" required>
            <input type="number" name="amount" placeholder="Target Amount" step="0.01" required>
            <input type="date" name="deadline_date" placeholder="Deadline Date" required>
            <textarea name="description" placeholder="Description"></textarea>
            <button type="submit">Create</button>
        </form>
    </div>
</div>

<div id="editSavingsModal" class="modal">
    <div class="modal-content">
        <span class="modal-close" onclick="closeModal('editSavingsModal')">&times;</span>
        <h2>Edit Savings Goal</h2>
        <form id="editSavingsForm" method="post" action="">
            <input type="hidden" name="action" value="edit_savings">
            <input type="hidden" name="saving_id" id="editSavingId">
            <input type="number" name="amount" placeholder="Amount" step="0.01" required>
            <select name="type">
                <option value="add to savings">Add to Savings</option>
                <option value="withdraw from savings">Withdraw from Savings</option>
            </select>
            <textarea name="description" placeholder="Transaction Description"></textarea>
            <button type="submit">Submit Transaction</button>
        </form>
    </div>
</div>

<div id="deleteSavingsModal" class="modal">
    <div class="modal-content">
        <span class="modal-close" onclick="closeModal('deleteSavingsModal')">&times;</span>
        <h2>Confirm Delete</h2>
        <form method="post" action="">
            <input type="hidden" name="action" value="delete_savings">
            <input type="hidden" name="saving_id" id="deleteSavingId">
            <p>Are you sure you want to delete this savings goal? The funds will be returned to your balance.</p>
            <button type="submit">Yes, Delete</button>
            <button type="button" onclick="closeModal('deleteSavingsModal')">Cancel</button>
        </form>
    </div>
</div>

<script>
function openModal(modalId) {
    document.getElementById(modalId).style.display = "flex";
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}

function openEditModal(savingId) {
    document.getElementById('editSavingId').value = savingId;
    openModal('editSavingsModal');
}

function openDeleteModal(savingId) {
    document.getElementById('deleteSavingId').value = savingId;
    openModal('deleteSavingsModal');
}
</script>
</body>
</html>
