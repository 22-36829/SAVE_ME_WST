<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

require('../../configs/db.php');

// Fetch the user data from the session or the database
$email = $_SESSION['email'];

$query = "SELECT * FROM User WHERE email = '$email'";
$result = $conn->query($query);

// Check if the query executed successfully and returned a result
if (!$result) {
    die("Error executing query: " . $conn->error); 
}

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $name = isset($user['name']) ? $user['name'] : 'Unknown User';
    $balance = isset($user['balance']) ? $user['balance'] : 0;

      // Total Savings from Transactions
      $savings_query = "SELECT COALESCE(SUM(st.amount), 0) AS total_savings
      FROM Savings_Transaction st
      JOIN Savings s ON st.saving_id = s.saving_id
      WHERE st.user_id = ? AND st.type = 'add to savings'";
$savings_stmt = $conn->prepare($savings_query);
$savings_stmt->bind_param("i", $user['user_id']);
$savings_stmt->execute();
$savings_result = $savings_stmt->get_result();
$total_savings = $savings_result->fetch_assoc()['total_savings'] ?? 0;


} else { 
    header('Location: ../login.php?msg=User not found');
    exit;
}

// Fetch recent transactions
$transaction_query = "
    SELECT * FROM Transaction 
    WHERE user_id = " . $user['user_id'] . " 
    ORDER BY transaction_date DESC 
    LIMIT 7";
$transaction_result = $conn->query($transaction_query);
if (!$transaction_result) {
    die("Error executing transaction query: " . $conn->error);
}
$transactions = $transaction_result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/pages/img/logo.png" type="image/x-icon">
    <title>Dashboard | Save ME</title>
   
    <link rel="stylesheet" href="./css/all.min.css" />
    <link rel="stylesheet" href="../user_dashboard/css/common.css" />
    <link rel="stylesheet" href="path/to/flag-icons.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

   
 
    
<body>

    <!-- Top Navigation -->
    <div class="navbar-top">
        
        <div class="navbar-buttons" >
            <button class="dropdown-btn"><img src="../img/bell.png" alt="Alerts" style="width: 16px; height: 16px;" ></button>
            <button class="dropdown-btn"><img src="../img/envelope.png" alt="Notifications" style="width: 16px; height: 16px;"></button>
            <a href="user_profile.php"><button class="dropdown-btn"><img src="../img/user.png" alt="Profile"style="width: 16px; height: 16px; padding-right:40px;"></button>
        </div>
    </div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                   
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="balance.php">
                        <i class="fas fa-wallet" style="margin-right: 8px;"></i><span>Balance</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="savings.php">
                        <i class="fas fa-piggy-bank" style="margin-right: 8px;"></i><span>Savings</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reports_analytics.php">
                        <i class="fas fa-chart-line" style="margin-right: 8px;"></i><span>Reports and Analytics</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="support.php">
                        <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar-alt" style="margin-right: 8px;"></i><span>Schedule</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../scripts/logout.php">
                        <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-content">
        <div class="welcome-header">
            <h3>Welcome, <?php echo $name; ?></h3>
        </div>

        <div class="income-inf-row">
            <div class="col-income">
                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            <div class="card-span">Balance</div>
                            <div class="card-price">₱ <?php echo number_format($balance); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-income">
                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            <div class="card-span">Total Savings</div>
                            <div class="card-price">₱ <?php echo number_format($total_savings, 2); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="overview-row">
            <div class="recent-transactions">
                <div class="earning-header">
                    <h6>Recent Transactions</h6>
                   
                </div>
                <div class="earning-body">
                    <table class="transaction-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Description</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
    <?php foreach ($transactions as $transaction): ?>
        <tr>
            <td><?php echo ucfirst($transaction['type']); ?></td>
            <td>
                <?php 
                // Determine the sign based on the transaction type
                if ($transaction['type'] === 'money in') {
                    echo '+'; // Show + for money in
                } else {
                    echo '-'; // Show - for money out
                }
                ?>
                <?php echo number_format($transaction['amount']); ?>
            </td>
            <td><?php echo htmlspecialchars($transaction['description']); ?></td>
            <td><?php echo date('Y-m-d H:i:s', strtotime($transaction['transaction_date'])); ?></td>
        </tr>
    <?php endforeach; ?>
</tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
