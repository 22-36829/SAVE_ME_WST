<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

require('../../configs/db.php');

// Fetch the user data from the session
$email = $_SESSION['email'];
$query = "SELECT * FROM User WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$name = $user['name'] ?? 'User';
$user_id = $user['user_id'];

// Get deadlines for the user's savings goals
$deadlines_query = "SELECT title, deadline_date FROM Savings WHERE user_id = ? AND status = 'in progress'";
$deadlines_stmt = $conn->prepare($deadlines_query);
$deadlines_stmt->bind_param("i", $user_id);
$deadlines_stmt->execute();
$deadlines_result = $deadlines_stmt->get_result();
$deadlines = [];
while ($row = $deadlines_result->fetch_assoc()) {
    $deadlines[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Schedule</title>
    <link rel="stylesheet" href="sample/style.css">
    <link rel="stylesheet" href="./css/all.min.css" />
    <link rel="stylesheet" href="../user_dashboard/css/common.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .main-content {
            margin-left: 250px;
            margin-top: 50px;
            padding: 20px;
            width: calc(100% - 250px);
        }
        .search-bar {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }
        .calendar-container {
            background-color: #E8F5E9;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 10px;
            font-size: 18px;
            font-weight: bold;
        }
        .calendar {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px;
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
        }
        .day-name, .day {
            padding: 10px;
            text-align: center;
            border-radius: 4px;
            font-weight: bold;
        }
        .day-name {
            background-color: #DCEED1;
            color: #333;
        }
        .day {
            background-color: #CFE3BC;
            cursor: pointer;
            position: relative;
            min-height: 80px;
        }
        .event-list {
            list-style: none;
            padding: 0;
            margin-top: 5px;
            font-size: 12px;
            color: #333;
        }
        .event-list li {
            text-align: left;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            position: relative;
        }
        /* Modal styling */
        .modal {
            display: none;
            position: fixed;
            z-index: 10;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fff;
            padding: 20px;
            width: 400px;
            border-radius: 10px;
            text-align: center;
            position: relative;
        }
        .close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="balance.php">
                        <i class="fas fa-wallet" style="margin-right: 8px;"></i><span>Balance</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="savings.php">
                        <i class="fas fa-piggy-bank" style="margin-right: 8px;"></i><span>Savings</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reports_analytics.php">
                        <i class="fas fa-chart-line" style="margin-right: 8px;"></i><span>Reports and Analytics</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="support.php">
                        <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar-alt" style="margin-right: 8px;"></i><span>Schedule</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../../scripts/logout.php">
                        <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>


    <!-- Top Navigation -->
    <div class="navbar-top">
       
    <div class="navbar-buttons" >
            <button class="dropdown-btn"><img src="../img/bell.png" alt="Alerts" style="width: 16px; height: 16px;" ></button>
            <button class="dropdown-btn"><img src="../img/envelope.png" alt="Notifications" style="width: 16px; height: 16px;"></button>
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile"style="width: 16px; height: 16px; padding-right:40px;"></button>
        </div>
    </div>

<div class="container">
    <!-- Main Content -->
    <div class="main-content">
        <h1>Set Schedules Here, <?php echo htmlspecialchars($name); ?></h1>

        <!-- Search Bar -->
        <div class="search-bar">
            <input type="month" id="month_year" placeholder="month and year">
            <label>
                <input type="checkbox" id="show_deadlines" onchange="toggleDeadlines()"> Show Deadlines
            </label>
            <button onclick="search()">Search</button>
            <button onclick="reset()">Reset</button>
        </div>

        <!-- Calendar Container -->
        <div class="calendar-container">
            <div class="calendar-header">
                <button onclick="prevMonth()">Previous</button>
                <span id="monthYear"></span>
                <button onclick="nextMonth()">Next</button>
            </div>
            <div class="calendar" id="calendar"></div>
        </div>
    </div>
</div>

<!-- Modal for Viewing and Adding Events -->
<div class="modal" id="viewEventsModal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h3 id="modalDate">Events on </h3>
        <div id="eventsList"></div>
        <h3>Add New Event</h3>
        <input type="text" id="newEventTitle" placeholder="Event Title" required>
        <textarea id="newEventDescription" placeholder="Event Description"></textarea>
        <button onclick="addEvent()">Add Event</button>
    </div>
</div>

<script>
    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();
    const deadlines = <?php echo json_encode($deadlines); ?>; // Fetch deadlines from PHP
    const events = JSON.parse(localStorage.getItem('events')) || [];
    let selectedDate = '';
    let showDeadlines = false; // Toggle for showing deadlines

    function renderCalendar() {
        const monthYear = document.getElementById('monthYear');
        monthYear.textContent = new Date(currentYear, currentMonth).toLocaleString('default', { month: 'long', year: 'numeric' });

        const calendar = document.getElementById('calendar');
        calendar.innerHTML = '';

        const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        dayNames.forEach(day => {
            const dayNameElement = document.createElement('div');
            dayNameElement.className = 'day-name';
            dayNameElement.innerText = day;
            calendar.appendChild(dayNameElement);
        });

        const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

        for (let i = 0; i < firstDayOfMonth; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.classList.add('day');
            calendar.appendChild(emptyCell);
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'day';
            dayElement.innerHTML = `<span>${day}</span>`;
            const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const eventsForDate = events.filter(event => event.date === dateStr);

            // Add events to the day
            if (eventsForDate.length > 0) {
                const eventList = document.createElement("ul");
                eventList.className = "event-list";
                eventsForDate.forEach(event => {
                    const eventItem = document.createElement("li");
                    eventItem.textContent = event.title;
                    eventList.appendChild(eventItem);
                });
                dayElement.appendChild(eventList);
            }

            // Highlight deadlines if toggle is enabled
            if (showDeadlines) {
                deadlines.forEach(deadline => {
                    if (deadline.deadline_date === dateStr) {
                        const deadlineTag = document.createElement("div");
                        deadlineTag.className = "deadline-tag";
                        deadlineTag.innerText = "Deadline: " + deadline.title;
                        dayElement.appendChild(deadlineTag);
                        dayElement.style.backgroundColor = "#FFECB3"; // Highlight deadline days
                    }
                });
            }

            dayElement.onclick = () => {
                selectedDate = dateStr;
                openViewEventsModal(dateStr);
            };
            calendar.appendChild(dayElement);
        }
    }

    function openViewEventsModal(dateStr) {
        selectedDate = dateStr;
        const eventsList = document.getElementById("eventsList");
        eventsList.innerHTML = '';

        const eventsForDate = events.filter(event => event.date === dateStr);
        if (eventsForDate.length > 0) {
            eventsForDate.forEach(event => {
                const eventItem = document.createElement("div");
                eventItem.className = "event-item";
                eventItem.innerHTML = `${event.title} - ${event.description} <button onclick="deleteEvent('${event.title}')">Delete</button>`;
                eventsList.appendChild(eventItem);
            });
        } else {
            eventsList.innerHTML = "<p>No events for this date.</p>";
        }
        document.getElementById("modalDate").textContent = `Events on ${selectedDate}`;
        document.getElementById("viewEventsModal").style.display = "flex";
    }

    function closeModal() {
        document.getElementById("viewEventsModal").style.display = "none";
    }

    function addEvent() {
        const title = document.getElementById("newEventTitle").value;
        const description = document.getElementById("newEventDescription").value;

        if (!title) {
            alert("Event title is required!");
            return;
        }

        events.push({ title, date: selectedDate, description });
        localStorage.setItem("events", JSON.stringify(events));
        location.reload(); // Reload the page to reflect changes
    }

    function deleteEvent(title) {
        const updatedEvents = events.filter(event => event.title !== title || event.date !== selectedDate);
        localStorage.setItem("events", JSON.stringify(updatedEvents));
        location.reload(); // Reload the page to reflect changes
    }

    function prevMonth() {
        if (currentMonth === 0) {
            currentMonth = 11;
            currentYear -= 1;
        } else {
            currentMonth -= 1;
        }
        renderCalendar();
    }

    function nextMonth() {
        if (currentMonth === 11) {
            currentMonth = 0;
            currentYear += 1;
        } else {
            currentMonth += 1;
        }
        renderCalendar();
    }

    function search() {
        const input = document.getElementById('month_year').value;
        if (!input) {
            alert('Please select a valid month and year.');
            return;
        }
        const [year, month] = input.split('-');
        currentYear = parseInt(year, 10);
        currentMonth = parseInt(month, 10) - 1;
        renderCalendar();
    }

    function reset() {
        document.getElementById('month_year').value = '';
        document.getElementById('show_deadlines').checked = false;
        showDeadlines = false;
        currentMonth = new Date().getMonth();
        currentYear = new Date().getFullYear();
        renderCalendar();
    }

    function toggleDeadlines() {
        showDeadlines = document.getElementById('show_deadlines').checked;
        renderCalendar();
    }

    document.addEventListener('DOMContentLoaded', renderCalendar);
</script>

</body>
</html>
