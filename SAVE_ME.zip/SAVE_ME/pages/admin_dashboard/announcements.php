<?php
// Enable error reporting for debugging (remove or comment out in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to login page if the admin is not logged in
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

// Include database connection
require('../../configs/db.php');

// Fetch the admin data from the session or the database
$email = $_SESSION['email'];

// Prepare the query to fetch admin details by email
$query = "SELECT * FROM Admin WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email); // Bind the email parameter to the query
$stmt->execute(); // Execute the query
$result = $stmt->get_result(); // Get the result set

// Check if the query executed successfully and returned a result
if (!$result) {
    die("Error executing query: " . $conn->error); 
}

// Fetch the admin data
if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    // Use htmlspecialchars to prevent XSS attacks
    $name = !empty($admin['fullname']) ? htmlspecialchars($admin['fullname']) : ''; 
    $admin_id = $admin['admin_id']; // Fetch the admin_id from the session data
} else { 
    // Redirect if no admin found
    header('Location: ../login.php?msg=Admin not found');
    exit;
}

// Close the statement
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_announcement'])) {
    // Get the input values from the form
    $title = $_POST['create_title'];
    $content = $_POST['create_content'];

    // Check if title and content are not empty
    if (!empty($title) && !empty($content)) {
        // Prepare the SQL statement to insert directly into the Announcement table
        $insertQuery = "INSERT INTO Announcement (title, content, admin_id) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param('ssi', $title, $content, $admin_id);

        if ($stmt->execute()) {
            echo "Announcement created and inserted into the database.";
        } else {
            echo "Error inserting announcement: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Title and Content fields cannot be empty.";
    }
}

// Prepare the base query for fetching announcements
$announcementListQuery = "SELECT announcement_id, title, content, announcement_date, updated_at, admin_id FROM Announcement WHERE 1=1";

// Initialize variables for search filters
$params = [];
$types = "";

// Add search condition for created_date (if provided)
if (isset($_GET['created_date']) && !empty($_GET['created_date'])) {
    $announcementListQuery .= " AND DATE(announcement_date) = ?";
    $params[] = $_GET['created_date'];
    $types .= "s"; // 's' for string (date)
}

// Add search condition for admin_id (if provided)
if (isset($_GET['admin_id']) && !empty($_GET['admin_id'])) {
    $announcementListQuery .= " AND admin_id = ?";
    $params[] = $_GET['admin_id'];
    $types .= "i"; // 'i' for integer
}

// Prepare the SQL statement
$stmt = $conn->prepare($announcementListQuery);

// Bind parameters dynamically (only if search parameters are provided)
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

// Execute the query
$stmt->execute();
$announcementListResult = $stmt->get_result(); // Fetch results

// Handle potential errors
if (!$announcementListResult) {
    die("Error fetching announcements: " . $conn->error);
}

// Handle the form submission to update an announcement
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_announcement'])) {
    $announcement_id = $_POST['announcement_id'];
    $title = $_POST['title'];
    $content = $_POST['content'];

    $updateQuery = "UPDATE Announcement SET title = ?, content = ? WHERE announcement_id = ?";
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->bind_param('ssi', $title, $content, $announcement_id);

    if ($updateStmt->execute()) {
        header('Location: announcements.php?msg=Announcement updated successfully');
        exit;
    } else {
        echo "Error updating announcement: " . $conn->error;
    }

    $updateStmt->close();
}

// Handle the delete action
if (isset($_GET['delete'])) {
    $announcement_id = $_GET['delete'];

    $deleteQuery = "DELETE FROM Announcement WHERE announcement_id = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param('i', $announcement_id);

    if ($deleteStmt->execute()) {
        header('Location: announcements.php?msg=Announcement deleted successfully');
        exit;
    } else {
        echo "Error deleting announcement: " . $conn->error;
    }

    $deleteStmt->close();
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Announcements| Save ME</title>
    <link rel="icon" href="../img/logo.png" type="image/x-icon">  
    
     <!-- CSS Links -->
     <link href="./admin_dashboard/css/index/mainMobile.css" rel="stylesheet">
    <link href="./admin_dashboard/css/index/table.css" media="(min-width: 600px)" rel="stylesheet">
    <link href="./admin_dashboard/css/index/desktop.css" media="(min-width: 900px)" rel="stylesheet">
    <link rel="stylesheet" href="../admin_dashboard/css/common.css">
    <link rel="stylesheet" href="../admin_dashboard/css/admin_acc.css"> 


   

    
< <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>

    
</head>

<body>
    <div class="navbar-top">
       
        <div class="navbar-buttons">
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile" style="width: 20px; height: 20px;"></button>
            <!-- Add more buttons if needed -->
        </div>
    </div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
        <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                   <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                </a>
            </li>

                <!-- Monitor Users Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-screen"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Users</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="user_account.php">User Account</a></li>
                        <li><a href="user_logs.php">User Logs</a></li>
                     
                    </ul>
                </li>

                <!-- Monitor Admins Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-display-code"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Admins</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="admin_account.php">Admin Account</a></li>
                        <li><a href="admin_logs.php">Admin Logs</a></li>
                       
                    </ul>
                </li>



                <li class="nav-item">
                    <a class="nav-link" href="announcements.php">
                    <i class="fi fi-rr-megaphone" style="margin-right: 8px;"></i><span>Announcements</span>
                    </a>
                </li>
            <li class="nav-item">
                <a class="nav-link" href="supports.php">
                <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                </a>
            </li>
                <li class="nav-item">
                        <a class="nav-link" href="../../scripts/logout.php">
                            <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                        </a>
                    </li>
            </ul>
        </div>


        <!-- Main Content -->
        <div class="main-content">
            <div class="welcome-header">
                <h3>Welcome to Announcements, <?php echo htmlspecialchars($name); ?></h3>
            </div>
            
            <div class="search-date">
                <form action="" method="GET">
                    <input type="date" name="created_date" value="<?php echo isset($_GET['created_date']) ? htmlspecialchars($_GET['created_date']) : ''; ?>" class="search-input">
                    <input type="text" name="admin_id" placeholder="Admin ID" value="<?php echo isset($_GET['admin_id']) ? htmlspecialchars($_GET['admin_id']) : ''; ?>" class="search-input">
                    <button type="submit" class="btn-search">Search</button>
                    <a href="announcements.php" class="btn-reset">Reset</a>
                </form>
            </div>

            <div class="income-inf-row">
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Active Users</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Inactive Users</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="create-announcement-form" style="display: none;">
                <form action="" method="POST">
                    <h2>Create New Announcement</h2>
                    <input type="text" name="create_title" placeholder="Title" required>
                    <textarea name="create_content" placeholder="Content" required></textarea>
                    <button type="submit" name="create_announcement">Submit</button>
                    <button type="button" onclick="closeCreateForm()">Cancel</button>
                </form>
            </div>

            <div class="update-announcement-form" style="display: none;">
                <form action="" method="POST">
                    <h2>Update Announcement</h2>
                    <input type="hidden" name="announcement_id" id="announcement_id">
                    <input type="text" name="title" id="update_title" required>
                    <textarea name="content" id="update_content" required></textarea>
                    <button type="submit" name="update_announcement">Submit</button>
                    <button type="button" onclick="closeUpdateForm()">Cancel</button>
                </form>
            </div>

            <div class="overview-row">
                <div class="recent-transactions">
                    <div class="earning-header">
                        <h6>Announcements</h6>
                        <button class="button-nobg" onclick="openCreateForm()">Create New Announcement</button>
                    </div>

                    <div class="earning-body">
                        <table class="transaction-table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Content</th>
                                    <th>Announcement Date</th>
                                    <th>Updated Date</th>
                                    <th>Admin ID</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $announcementListResult->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                                        <td><?php echo htmlspecialchars($row['content']); ?></td>
                                        <td><?php echo htmlspecialchars($row['announcement_date']); ?></td>
                                        <td><?php echo htmlspecialchars($row['updated_at']); ?></td>
                                        <td><?php echo htmlspecialchars($row['admin_id']); ?></td>
                                        <td>
    <button class="button-update" onclick="openUpdateForm(<?php echo $row['announcement_id']; ?>, '<?php echo htmlspecialchars($row['title']); ?>', '<?php echo htmlspecialchars($row['content']); ?>')">Update</button>
    <button type="button" class="button-delete" onclick="if(confirm('Are you sure you want to delete this announcement?')) { window.location.href='announcements.php?delete=<?php echo $row['announcement_id']; ?>'; }">Delete</button>
</td>

                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

          
        </div>
    </div>

    <script>
        function openCreateForm() {
            document.querySelector('.create-announcement-form').style.display = 'block';
        }

        function closeCreateForm() {
            document.querySelector('.create-announcement-form').style.display = 'none';
        }

        function openUpdateForm(id, title, content) {
            document.getElementById('announcement_id').value = id;
            document.getElementById('update_title').value = title;
            document.getElementById('update_content').value = content;
            document.querySelector('.update-announcement-form').style.display = 'block';
        }

        function closeUpdateForm() {
            document.querySelector('.update-announcement-form').style.display = 'none';
        }
    </script>
    <script src="../admin_dashboard/js/common.js"></script>
</body>

</html>
