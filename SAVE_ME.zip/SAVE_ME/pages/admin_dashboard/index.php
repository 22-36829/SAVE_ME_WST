<?php
// Enable error reporting for debugging (remove or comment out in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to login page if the admin is not logged in
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

// Include database connection
require('../../configs/db.php');

// Fetch the admin data from the session or the database
$email = $_SESSION['email'];

// Prepare the query to fetch admin details by email
$query = "SELECT * FROM Admin WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email); // Bind the email parameter to the query
$stmt->execute(); // Execute the query
$result = $stmt->get_result(); // Get the result set

// Check if the query executed successfully and returned a result
if (!$result) {
    die("Error executing query: " . $conn->error); 
}

// Fetch the admin data
if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    // Use htmlspecialchars to prevent XSS attacks
    $name = !empty($admin['fullname']) ? htmlspecialchars($admin['fullname']) : ''; 
} else { 
    // Redirect if no admin found
    header('Location: ../login.php?msg=Admin not found');
    exit;
}

// Close the statement
$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <title>Admin Dashboard | Save ME</title>
    
    
     <!-- CSS Links -->
     <link href="./admin_dashboard/css/index/mainMobile.css" rel="stylesheet">
    <link href="./admin_dashboard/css/index/table.css" media="(min-width: 600px)" rel="stylesheet">
    <link href="./admin_dashboard/css/index/desktop.css" media="(min-width: 900px)" rel="stylesheet">
    <link rel="stylesheet" href="../admin_dashboard/css/common.css">
    <link rel="stylesheet" href="path/to/flag-icons.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>

    
</head>

<body>
    <div class="navbar-top">
       
        <div class="navbar-buttons">
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile" style="width: 20px; height: 20px;"></button>
            <!-- Add more buttons if needed -->
        </div>
    </div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
        <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                   <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                </a>
            </li>

                <!-- Monitor Users Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-screen"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Users</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="user_account.php">User Account</a></li>
                        <li><a href="user_logs.php">User Logs</a></li>
                     
                    </ul>
                </li>

                <!-- Monitor Admins Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-display-code"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Admins</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="admin_account.php">Admin Account</a></li>
                        <li><a href="admin_logs.php">Admin Logs</a></li>
                       
                    </ul>
                </li>



                <li class="nav-item">
                    <a class="nav-link" href="announcements.php">
                    <i class="fi fi-rr-megaphone" style="margin-right: 8px;"></i><span>Announcements</span>
                    </a>
                </li>
            <li class="nav-item">
                <a class="nav-link" href="supports.php">
                <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                </a>
            </li>
                <li class="nav-item">
                        <a class="nav-link" href="../../scripts/logout.php">
                            <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                        </a>
                    </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="welcome-header">
                <h3>Welcome, <?php echo htmlspecialchars($name); ?></h3>
            </div>

            <div class="income-inf-row">
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Active Users</div>
                                <!-- Add relevant data or content here -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Inactive Users</div>
                                <!-- Add relevant data or content here -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="overview-row">
                <div class="recent-transactions">
                    <div class="earning-header">
                        <h6>Recent Transactions</h6>
                        <button class="button-nobg"><i class="fas fa-ellipsis-v"></i></button>
                    </div>
                    <div class="earning-body">
                        <table class="transaction-table">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Add select query for transactions -->
                                <?php
                                // Example PHP code to fetch and display transactions
                                /*
                                $transQuery = "SELECT type, amount, description, date FROM transactions WHERE admin_email = '$email' ORDER BY date DESC LIMIT 10";
                                $transResult = $conn->query($transQuery);
                                if ($transResult && $transResult->num_rows > 0) {
                                    while ($trans = $transResult->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($trans['type']) . "</td>";
                                        echo "<td>" . htmlspecialchars($trans['amount']) . "</td>";
                                        echo "<td>" . htmlspecialchars($trans['description']) . "</td>";
                                        echo "<td>" . htmlspecialchars($trans['date']) . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4'>No transactions found.</td></tr>";
                                }
                                */
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Font Awesome -->
    <script defer src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="../admin_dashboard/js/common.js"></script>

</body>

</html>
