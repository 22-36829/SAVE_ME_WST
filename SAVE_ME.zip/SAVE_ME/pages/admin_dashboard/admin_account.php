<?php
// Enable error reporting for debugging (remove or comment out in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to login page if the admin is not logged in
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

// Include database connection
require('../../configs/db.php');

// Fetch the admin data from the session or the database
$email = $_SESSION['email'];

// Prepare the query to fetch admin details by email
$query = "SELECT fullname FROM Admin WHERE email = ? AND status != 'deleted'";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email); // Bind the email parameter
$stmt->execute(); // Execute the query
$result = $stmt->get_result(); // Get the result set

// Check if the query returned a result
if ($result && $result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    // Use htmlspecialchars to prevent XSS attacks
    $name = htmlspecialchars($admin['fullname']);
} else {
    // Redirect if no admin found
    header('Location: ../login.php?msg=Admin not found');
    exit;
}

// Close the statement
$stmt->close();

// Fetch admin counts based on status
$adminCountsQuery = "SELECT 
                        SUM(status = 'active') AS active_count, 
                        SUM(status = 'inactive') AS inactive_count, 
                        SUM(status = 'deleted') AS deleted_count 
                    FROM Admin";
$adminCountsResult = $conn->query($adminCountsQuery);
$adminCounts = $adminCountsResult->fetch_assoc();

// Fetch admin accounts based on search criteria
$searchName = isset($_GET['search_name']) ? $_GET['search_name'] : '';
$createdDate = isset($_GET['created_date']) ? $_GET['created_date'] : '';
$statusFilter = isset($_GET['status_filter']) ? $_GET['status_filter'] : '';

// Initialize the admin list query
$adminListQuery = "SELECT admin_id, fullname, role, email, number, status, created_at, ended_at FROM Admin"; // Fetch all admins

// Prepare conditions for the query
$conditions = [];

if (!empty($searchName)) {
    $conditions[] = "fullname LIKE CONCAT('%', ?, '%')";
}

if (!empty($createdDate)) {
    $conditions[] = "DATE(created_at) = ?";
}

// If a status filter is provided, include it in the query
if (!empty($statusFilter)) {
    $conditions[] = "status = ?";
}

// Combine conditions into the query
if (count($conditions) > 0) {
    $adminListQuery .= " WHERE " . implode(' AND ', $conditions);
}

// Prepare the statement
$stmt = $conn->prepare($adminListQuery);

// Bind parameters dynamically
$params = [];
$types = '';

if (!empty($searchName)) {
    $params[] = $searchName;
    $types .= 's'; // String type
}

if (!empty($createdDate)) {
    $params[] = $createdDate;
    $types .= 's'; // String type (date)
}

if (!empty($statusFilter)) {
    $params[] = $statusFilter;
    $types .= 's'; // String type
}

// Bind parameters if there are any
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

// Execute the query to fetch admin list
$stmt->execute();
$adminListResult = $stmt->get_result();

// Handle the form submission to create a new admin
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_admin'])) {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Plain text password (not secure for production)
    $role = $_POST['role'];
    $number = $_POST['number'];

    // Hash password for security (for now displaying plain text)
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $createQuery = "INSERT INTO Admin (fullname, role, email, password, number, status, created_at) 
                    VALUES (?, ?, ?, ?, ?, 'active', NOW())";
    $createStmt = $conn->prepare($createQuery);
    $createStmt->bind_param('sssss', $fullname, $role, $email, $hashedPassword, $number);

    if ($createStmt->execute()) {
        // Refresh the page to show the new admin in the list
        header('Location: admin_account.php?msg=Admin created successfully');
        exit;
    } else {
        echo "Error creating admin: " . $conn->error;
    }

    $createStmt->close();
}

// Handle the form submission to update admin details
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_admin'])) {
    $admin_id = $_POST['admin_id'];
    $fullname = $_POST['fullname'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $status = $_POST['status'];
    $ended_at = empty($_POST['ended_at']) ? NULL : $_POST['ended_at'];

    // Fetch current values from the database for comparison
    $currentQuery = "SELECT fullname, role, email, number, status, ended_at FROM Admin WHERE admin_id = ?";
    $currentStmt = $conn->prepare($currentQuery);
    $currentStmt->bind_param('i', $admin_id);
    $currentStmt->execute();
    $currentResult = $currentStmt->get_result();

    if ($currentResult && $currentResult->num_rows > 0) {
        $currentData = $currentResult->fetch_assoc();

        // Check if any of the values have changed
        $isChanged = (
            $currentData['fullname'] !== $fullname ||
            $currentData['role'] !== $role ||
            $currentData['email'] !== $email ||
            $currentData['number'] !== $number ||
            $currentData['status'] !== $status ||
            $currentData['ended_at'] !== $ended_at
        );

        if ($isChanged) {
            // Prepare the update query
            $updateQuery = "UPDATE Admin SET fullname = ?, role = ?, email = ?, number = ?, status = ?, ended_at = ? WHERE admin_id = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param('ssssssi', $fullname, $role, $email, $number, $status, $ended_at, $admin_id);

            if ($updateStmt->execute()) {
                // Redirect back to the same page to refresh admin data
                header('Location: admin_account.php?msg=Admin updated successfully');
                exit;
            } else {
                echo "Error updating admin: " . $conn->error;
            }
            $updateStmt->close();
        } else {
            // Display warning message if no changes were made
            echo "<script>alert('No changes were made to the admin details.');</script>";
        }
    } else {
        echo "Error: Admin not found.";
    }

    $currentStmt->close();
}

// Handle admin deletion (soft delete)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_admin'])) {
    $admin_id = $_POST['admin_id'];
    $deleteQuery = "UPDATE Admin SET status = 'deleted', deleted_at = NOW() WHERE admin_id = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param('i', $admin_id);

    if ($deleteStmt->execute()) {
        // Redirect back to the same page to refresh admin data
        header('Location: admin_account.php?msg=Admin deleted successfully');
        exit;
    } else {
        echo "Error deleting admin: " . $conn->error;
    }
    $deleteStmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <title>Admin Dashboard | Admin Accounts | Save ME</title>
 
    
    

    <!-- CSS Links -->
    <link href="./admin_dashboard/css/index/mainMobile.css" rel="stylesheet">
    <link href="./admin_dashboard/css/index/table.css" media="(min-width: 600px)" rel="stylesheet">
    <link href="./admin_dashboard/css/index/desktop.css" media="(min-width: 900px)" rel="stylesheet">
    <link rel="stylesheet" href="../admin_dashboard/css/common.css">
    <link rel="stylesheet" href="../admin_dashboard/css/admin_acc.css"> <!-- Link to your custom data grid CSS -->


 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>

    
</head>

<body>
    <div class="navbar-top">
       
        <div class="navbar-buttons">
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile" style="width: 20px; height: 20px;"></button>
            <!-- Add more buttons if needed -->
        </div>
    </div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
        <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                   <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                </a>
            </li>

                <!-- Monitor Users Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-screen"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Users</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="user_account.php">User Account</a></li>
                        <li><a href="user_logs.php">User Logs</a></li>
                     
                    </ul>
                </li>

                <!-- Monitor Admins Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-display-code"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Admins</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="admin_account.php">Admin Account</a></li>
                        <li><a href="admin_logs.php">Admin Logs</a></li>
                       
                    </ul>
                </li>



                <li class="nav-item">
                    <a class="nav-link" href="announcements.php">
                    <i class="fi fi-rr-megaphone" style="margin-right: 8px;"></i><span>Announcements</span>
                    </a>
                </li>
            <li class="nav-item">
                <a class="nav-link" href="supports.php">
                <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                </a>
            </li>
                <li class="nav-item">
                        <a class="nav-link" href="../../scripts/logout.php">
                            <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                        </a>
                    </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="welcome-header">
                <h3>Welcome to Admin Accounts, <?php echo $name; ?></h3>
            </div>

            <div class="income-inf-row">
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Active Admins: <?php echo $adminCounts['active_count']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Inactive Admins: <?php echo $adminCounts['inactive_count']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Deleted Admins: <?php echo $adminCounts['deleted_count']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="search-date">
    <form method="GET" action="">
        <label for="search_name">Search Name:</label>
        <input type="text" class="search-name"  id="search_name" name="search_name" value="<?php echo htmlspecialchars($searchName); ?>" placeholder="Enter name...">
        
        <label for="created_date">Created Date:</label>
        <input type="date" class="search-date"  id="created_date" name="created_date" value="<?php echo htmlspecialchars($createdDate); ?>">

        <!-- Dropdown for Status Filter -->
        <label for="status_filter" >Status:</label>
        <select name="status_filter" class="search-name"   id="status_filter">
            <option value="">All</option>
            <option value="active" <?php if (isset($_GET['status_filter']) && $_GET['status_filter'] == 'active') echo 'selected'; ?>>Active</option>
            <option value="inactive" <?php if (isset($_GET['status_filter']) && $_GET['status_filter'] == 'inactive') echo 'selected'; ?>>Inactive</option>
            <option value="deleted" <?php if (isset($_GET['status_filter']) && $_GET['status_filter'] == 'deleted') echo 'selected'; ?>>Deleted</option>
        </select>
        
        <input type="submit" value="Search" class="btn-search">
        <a href="admin_account.php" class="btn-reset">Reset</a>
    </form>
</div>


            <!-- Create Admin Form -->
            <div class="create-admin-form">
                <h4>Create New Admin</h4>
                <form method="POST" action="">
                    <label for="fullname">Full Name:</label>
                    <input type="text" id="fullname" name="fullname" required placeholder="Enter full name...">

                    <label for="role">Role:</label>
                    <input type="text" id="role" name="role" required placeholder="Enter role...">

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required placeholder="Enter email...">

                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required placeholder="Enter password...">

                    <label for="number">Phone Number:</label>
                    <input type="text" id="number" name="number" required placeholder="Enter phone number...">

                    <input type="submit" name="create_admin" value="Create Admin">
                </form>
            </div>

            <div class="data-grid">
    <table class="transaction-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Role</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Status</th>
                <th>Created Date</th>
                <th>Ended Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($admin = $adminListResult->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($admin['admin_id']); ?></td>
                    <td><?php echo htmlspecialchars($admin['fullname']); ?></td>
                    <td><?php echo htmlspecialchars($admin['role']); ?></td>
                    <td><?php echo htmlspecialchars($admin['email']); ?></td>
                    <td><?php echo htmlspecialchars($admin['number']); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($admin['status'])); ?></td> <!-- Display status as text -->
                    <td><?php echo htmlspecialchars($admin['created_at']); ?></td>
                    <td>
                        <?php 
                        // Set default value to "STILL ACTIVE" if ended_at is null
                        $endedAt = $admin['ended_at'] ?? 'STILL ACTIVE'; 
                        echo htmlspecialchars($endedAt); 
                        ?>
                    </td>
                    <td>
                        <form method="POST" action="admin_account.php"> <!-- Change to your action URL -->
                            <input type="hidden" name="admin_id" value="<?php echo $admin['admin_id']; ?>">

                            <!-- Editable fields -->
                            <input type="text" name="fullname" placeholder="Full Name" value="<?php echo htmlspecialchars($admin['fullname']); ?>" required>
                            <input type="text" name="role" placeholder="Role" value="<?php echo htmlspecialchars($admin['role']); ?>" required>
                            <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                            <input type="text" name="number" placeholder="Phone Number" value="<?php echo htmlspecialchars($admin['number']); ?>" required>
                            
                            <!-- Editable Status Dropdown -->
                            <select name="status" required>
                                <option value="active" <?php if ($admin['status'] == 'active') echo 'selected'; ?>>Active</option>
                                <option value="inactive" <?php if ($admin['status'] == 'inactive') echo 'selected'; ?>>Inactive</option>
                                <option value="deleted" <?php if ($admin['status'] == 'deleted') echo 'selected'; ?>>Deleted</option>
                            </select>

                            <input type="date" name="ended_at" value="<?php echo htmlspecialchars($admin['ended_at']); ?>">
                            
                            <input type="submit" name="update_admin" value="Update">
                            <input type="submit" name="delete_admin" value="Delete" onclick="return confirm('Are you sure you want to delete this admin?')">
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

    </div>

    <script src="../admin_dashboard/js/common.js"></script>
</body>
</html>
