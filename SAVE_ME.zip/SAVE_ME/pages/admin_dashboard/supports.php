<?php
// Enable error reporting for debugging (remove or comment out in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to login page if the admin is not logged in
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

// Include database connection
require('../../configs/db.php');

// Fetch the admin data from the session or the database
$email = $_SESSION['email'];

// Prepare the query to fetch admin details by email
$query = "SELECT * FROM Admin WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email); // Bind the email parameter to the query
$stmt->execute(); // Execute the query
$result = $stmt->get_result(); // Get the result set

// Check if the query executed successfully and returned a result
if (!$result) {
    die("Error executing query: " . $conn->error); 
}

// Fetch the admin data
if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    // Use htmlspecialchars to prevent XSS attacks
    $name = !empty($admin['fullname']) ? htmlspecialchars($admin['fullname']) : ''; 
} else { 
    // Redirect if no admin found
    header('Location: ../login.php?msg=Admin not found');
    exit;
}

// Close the statement
$stmt->close();

// Update admin reply if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reply_submit'])) {
    $support_id = $_POST['support_id'];
    $admin_reply = $_POST['admin_reply'];

    // Update the admin reply in the database
    $update_query = "UPDATE Support SET admin_reply = ?, reply_at = NOW() WHERE support_id = ?";
    $update_stmt = $conn->prepare($update_query);
    
    // Bind the parameters (remove admin_id)
    $update_stmt->bind_param('si', $admin_reply, $support_id);
    
    if ($update_stmt->execute()) {
        // Optionally redirect or show a success message
        header('Location: supports.php?msg=Reply updated successfully');
        exit;
    } else {
        die("Error updating reply: " . $conn->error);
    }
}


// Handle support deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_support'])) {
    $support_id = $_POST['support_id'];

    // Prepare delete query
    $delete_query = "DELETE FROM Support WHERE support_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param('i', $support_id);
    
    if ($delete_stmt->execute()) {
        header('Location: supports.php?msg=Support ticket deleted successfully');
        exit;
    } else {
        die("Error deleting support: " . $conn->error);
    }
}

// Search functionality
$searchName = '';
$createdDate = '';
$searchStatus = ''; // To store the selected status
$search_query = '';

// Check for search parameters
if (isset($_GET['search_name']) || isset($_GET['created_date']) || isset($_GET['search_status'])) {
    $searchName = $_GET['search_name'] ?? '';
    $createdDate = $_GET['created_date'] ?? '';
    $searchStatus = $_GET['search_status'] ?? '';
    
    $search_query .= " WHERE 1=1"; // Start with a base query for optional parameters

    if (!empty($searchName)) {
        $search_query .= " AND u.name LIKE ?"; // Assuming you are searching by user name
    }
    if (!empty($createdDate)) {
        $search_query .= " AND DATE(s.created_at) = ?";
    }
    if (!empty($searchStatus)) {
        $search_query .= " AND (s.admin_reply IS NULL OR s.admin_reply = '' AND ? = 'pending') OR (s.admin_reply IS NOT NULL AND s.admin_reply != '' AND ? = 'answered')";
    }
}

// Updated SQL query to fetch support tickets
$support_query = "
    SELECT s.*, u.name AS user_name 
    FROM Support s
    JOIN User u ON s.user_id = u.user_id
" . $search_query;

// Fetch support tickets from the database
$support_stmt = $conn->prepare($support_query);

// Bind parameters if they exist
$params = [];
if (!empty($searchName)) {
    $params[] = "%" . $searchName . "%"; // Add wildcard for partial matching
}
if (!empty($createdDate)) {
    $params[] = $createdDate; // Exact date match
}
if (!empty($searchStatus)) {
    $params[] = $searchStatus; // Add the selected status
    $params[] = $searchStatus; // Add the selected status again for the other condition
}

// Dynamically bind parameters if present
if (count($params) > 0) {
    $types = str_repeat('s', count($params)); // Generate types for binding
    $support_stmt->bind_param($types, ...$params);
}

$support_stmt->execute();
$support_result = $support_stmt->get_result();

// Initialize counters
$pending_count = 0;
$answered_count = 0;

if ($support_result && $support_result->num_rows > 0) {
    while ($support = $support_result->fetch_assoc()) {
        // Count pending and answered supports
        if (empty($support['admin_reply']) || $support['admin_reply'] === 'Pending') {
            $pending_count++;
        } else {
            $answered_count++;
        }
    }
} else {
    $pending_count = 0; // Ensure the count is set even if no results
    $answered_count = 0; // Ensure the count is set even if no results
}

// Close the connection
$support_stmt->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <title>Admin Dashboard |Supports| Save ME</title>
    
    
    <!-- CSS Links -->
    <link href="./admin_dashboard/css/index/mainMobile.css" rel="stylesheet">
    <link href="./admin_dashboard/css/index/table.css" media="(min-width: 600px)" rel="stylesheet">
    <link href="./admin_dashboard/css/index/desktop.css" media="(min-width: 900px)" rel="stylesheet">
    <link rel="stylesheet" href="../admin_dashboard/css/common.css">
    <link rel="stylesheet" href="../admin_dashboard/css/admin_acc.css"> <!-- Link to your custom data grid CSS -->
   

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>

    
</head>

<body>
    <div class="navbar-top">
       
        <div class="navbar-buttons">
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile" style="width: 20px; height: 20px;"></button>
            <!-- Add more buttons if needed -->
        </div>
    </div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
        <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                   <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                </a>
            </li>

                <!-- Monitor Users Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-screen"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Users</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="user_account.php">User Account</a></li>
                        <li><a href="user_logs.php">User Logs</a></li>
                     
                    </ul>
                </li>

                <!-- Monitor Admins Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-display-code"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Admins</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="admin_account.php">Admin Account</a></li>
                        <li><a href="admin_logs.php">Admin Logs</a></li>
                       
                    </ul>
                </li>



                <li class="nav-item">
                    <a class="nav-link" href="announcements.php">
                    <i class="fi fi-rr-megaphone" style="margin-right: 8px;"></i><span>Announcements</span>
                    </a>
                </li>
            <li class="nav-item">
                <a class="nav-link" href="supports.php">
                <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                </a>
            </li>
                <li class="nav-item">
                        <a class="nav-link" href="../../scripts/logout.php">
                            <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                        </a>
                    </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="welcome-header">
                <h3>Welcome to Supports, <?php echo htmlspecialchars($name); ?></h3>
            </div>

            <div class="income-inf-row">
                <div class="col-income">
                    <div class="card">
                        <div class="card-content">
                            <h4>Total Pending Supports</h4>
                            <p><?php echo $pending_count; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-income">
                    <div class="card">
                        <div class="card-content">
                            <h4>Total Answered Supports</h4>
                            <p><?php echo $answered_count; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="search-date">
                <form action="" method="GET">
                    <input type="text" name="search_name" placeholder="Search by User Name" value="<?php echo htmlspecialchars($searchName); ?>" class="search-input">
                    <input type="date" name="created_date" value="<?php echo htmlspecialchars($createdDate); ?>" class="search-input">
                    <select name="search_status" class="search-input">
                        <option value="" <?php if ($searchStatus == '') echo 'selected'; ?>>All</option>
                        <option value="pending" <?php if ($searchStatus == 'pending') echo 'selected'; ?>>Pending</option>
                        <option value="answered" <?php if ($searchStatus == 'answered') echo 'selected'; ?>>Answered</option>
                    </select>
                    <button type="submit" class="btn-search">Search</button>
                    <a href="supports.php" class="btn-reset">Reset</a>
                </form>
            </div>

            <div class="data-grid">
    <table class="data-table">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Concern</th>
                <th>Admin Reply</th>
                <th>Created At</th>
                <th>Reply At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Display the support tickets
            if ($support_result && $support_result->num_rows > 0) {
                $support_result->data_seek(0); // Reset result pointer
                while ($support = $support_result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($support['user_name']) . '</td>';
                    echo '<td>' . htmlspecialchars($support['concern']) . '</td>'; // Updated to match your 'Concern' field

                    // Admin Reply field with a form containing the reply
                    echo '<td>
                            <form method="POST" action="">
                                <textarea name="admin_reply" rows="2">' . 
                                (!empty($support['admin_reply']) ? htmlspecialchars($support['admin_reply']) : 'Pending') . 
                                '</textarea>
                                <input type="hidden" name="support_id" value="' . $support['support_id'] . '">
                          </td>';

                    echo '<td>' . htmlspecialchars($support['created_at']) . '</td>';
                    echo '<td>' . (!empty($support['reply_at']) ? htmlspecialchars($support['reply_at']) : 'N/A') . '</td>';

                    // Action column with Update and Delete buttons
                    echo '<td>
                                <button type="submit" name="reply_submit" class="button-update">Send</button>
                            </form> <!-- Close the form here -->
                            <form method="POST" action="" onsubmit="return confirmDelete();">
                                <input type="hidden" name="support_id" value="' . $support['support_id'] . '">
                                <button type="submit" name="delete_support" class="button-delete">Delete</button>
                            </form>
                          </td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="6">No support tickets found.</td></tr>'; // Updated colspan to match the number of columns
            }
            ?>
        </tbody>
    </table>
</div>

<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this support ticket?");
    }
</script>



        </div>
    </div>

    <!-- Font Awesome -->
    <script defer src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="../admin_dashboard/js/common.js"></script>

</body>

</html>
