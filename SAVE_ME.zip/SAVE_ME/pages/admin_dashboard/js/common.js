// Dropdown functionality for sidebar
document.querySelectorAll('.dropdown-header').forEach(header => {
    header.addEventListener('click', function () {
        const dropdown = this.parentElement;
        const dropdownContent = dropdown.querySelector('.dropdown-content');

        // Toggle the active class on the dropdown
        dropdown.classList.toggle('active');

        // Show or hide the dropdown content based on the active class
        dropdownContent.style.display = dropdown.classList.contains('active') ? 'block' : 'none';

        // Close other dropdowns
        document.querySelectorAll('.dropdown').forEach(otherDropdown => {
            if (otherDropdown !== dropdown) {
                otherDropdown.classList.remove('active');
                otherDropdown.querySelector('.dropdown-content').style.display = 'none';
            }
        });
    });
});

// Optional: Close dropdown when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.dropdown')) {
        document.querySelectorAll('.dropdown').forEach(dropdown => {
            dropdown.classList.remove('active');
            dropdown.querySelector('.dropdown-content').style.display = 'none';
        });
    }
});
