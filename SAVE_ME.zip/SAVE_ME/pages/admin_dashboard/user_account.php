<?php
// Enable error reporting for debugging (remove or comment out in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to login page if the admin is not logged in
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

// Include database connection
require('../../configs/db.php');

// Fetch the admin data from the session or the database
$email = $_SESSION['email'];

// Prepare the query to fetch admin details by email
$query = "SELECT fullname FROM Admin WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email); // Bind the email parameter
$stmt->execute(); // Execute the query
$result = $stmt->get_result(); // Get the result set

// Check if the query returned a result
if ($result && $result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    // Use htmlspecialchars to prevent XSS attacks
    $name = htmlspecialchars($admin['fullname']);
} else {
    // Redirect if no admin found
    header('Location: ../login.php?msg=Admin not found');
    exit;
}

// Close the statement
$stmt->close();

// Fetch user counts
$userCountsQuery = "SELECT 
                        SUM(status = 'active') AS active_count, 
                        SUM(status = 'inactive') AS inactive_count, 
                        SUM(status = 'deleted') AS deleted_count 
                    FROM User";
$userCountsResult = $conn->query($userCountsQuery);
$userCounts = $userCountsResult->fetch_assoc();

// Fetch user accounts based on search criteria
$searchName = isset($_GET['search_name']) ? $_GET['search_name'] : '';
$createdDate = isset($_GET['created_date']) ? $_GET['created_date'] : '';
$userListQuery = "SELECT user_id, name, email, mobile_num, status, updated_at, created_at FROM User WHERE 1=1"; // Include user_id for updates

if (!empty($searchName)) {
    $userListQuery .= " AND name LIKE CONCAT('%', ?, '%')";
}

if (!empty($createdDate)) {
    $userListQuery .= " AND DATE(created_at) = ?";
}

$stmt = $conn->prepare($userListQuery);

if (!empty($searchName) && !empty($createdDate)) {
    $stmt->bind_param('ss', $searchName, $createdDate);
} elseif (!empty($searchName)) {
    $stmt->bind_param('s', $searchName);
} elseif (!empty($createdDate)) {
    $stmt->bind_param('s', $createdDate);
}

$stmt->execute();
$userListResult = $stmt->get_result();

// Handle the form submission to update user details
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_user'])) {
    $user_id = $_POST['user_id'];
    $status = $_POST['status'];

    // Prepare the update query to only update status
    $updateQuery = "UPDATE User SET status = ? WHERE user_id = ?";
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->bind_param('si', $status, $user_id); // Bind only status and user_id
    
    if ($updateStmt->execute()) {
        // Redirect back to the same page to refresh user data
        header('Location: user_account.php?msg=User status updated successfully');
        exit;
    } else {
        echo "Error updating user: " . $conn->error;
    }
    $updateStmt->close();
}


// Handle user deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $deleteQuery = "DELETE FROM User WHERE user_id = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param('i', $user_id);
    
    if ($deleteStmt->execute()) {
        // Redirect back to the same page to refresh user data
        header('Location: user_account.php?msg=User deleted successfully');
        exit;
    } else {
        echo "Error deleting user: " . $conn->error;
    }
    $deleteStmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <title>Admin Dashboard | User Account | Save ME</title>
 
    
    <!-- CSS Links -->
    <link href="./admin_dashboard/css/index/mainMobile.css" rel="stylesheet">
    <link href="./admin_dashboard/css/index/table.css" media="(min-width: 600px)" rel="stylesheet">
    <link href="./admin_dashboard/css/index/desktop.css" media="(min-width: 900px)" rel="stylesheet">
    <link rel="stylesheet" href="../admin_dashboard/css/common.css">
    <link rel="stylesheet" href="../admin_dashboard/css/admin_acc.css"> <!-- Link to your custom data grid CSS -->


 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>

    
</head>

<body>
    <div class="navbar-top">
       
        <div class="navbar-buttons">
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile" style="width: 20px; height: 20px;"></button>
            <!-- Add more buttons if needed -->
        </div>
    </div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
        <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                   <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                </a>
            </li>

                <!-- Monitor Users Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-screen"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Users</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="user_account.php">User Account</a></li>
                        <li><a href="user_logs.php">User Logs</a></li>
                     
                    </ul>
                </li>

                <!-- Monitor Admins Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-display-code"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Admins</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="admin_account.php">Admin Account</a></li>
                        <li><a href="admin_logs.php">Admin Logs</a></li>
                       
                    </ul>
                </li>



                <li class="nav-item">
                    <a class="nav-link" href="announcements.php">
                    <i class="fi fi-rr-megaphone" style="margin-right: 8px;"></i><span>Announcements</span>
                    </a>
                </li>
            <li class="nav-item">
                <a class="nav-link" href="supports.php">
                <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                </a>
            </li>
                <li class="nav-item">
                        <a class="nav-link" href="../../scripts/logout.php">
                            <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                        </a>
                    </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="welcome-header">
                <h3>Welcome to User Accounts, <?php echo $name; ?></h3>
            </div>

            <div class="income-inf-row">
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Active Users: <?php echo $userCounts['active_count']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Inactive Users: <?php echo $userCounts['inactive_count']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-income">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-text">
                                <div class="card-span">Deleted Users: <?php echo $userCounts['deleted_count']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="search-date">
                <form method="GET" action="">
                    <label for="search_name">Search Name:</label>
                    <input type="text" id="search_name" name="search_name" value="<?php echo htmlspecialchars($searchName); ?>" placeholder="Enter name...">
                    
                    <label for="created_date">Created Date:</label>
                    <input type="date" id="created_date" name="created_date" value="<?php echo htmlspecialchars($createdDate); ?>">

                    <input type="submit" value="Search" class="btn-search">
                    <a href="user_account.php" class="btn-reset">Reset</a>
                </form>
            </div>

            <div class="data-grid">
                <h3>User Accounts</h3>
                <table class="transaction-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile Number</th>
                            <th>Status</th>
                            <th>Updated Date</th>
                            <th>Created Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if ($userListResult->num_rows > 0) {
                                while ($user = $userListResult->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . htmlspecialchars($user['name']) . "</td>"; // Name is non-editable
                                    echo "<td>" . htmlspecialchars($user['email']) . "</td>"; // Email is non-editable
                                    echo "<td>" . htmlspecialchars($user['mobile_num']) . "</td>"; // Mobile number is non-editable
                                    echo "<td>
                                            <form method='POST' action=''>
                                            <div class='status-dropdown'>
                                            <select name='status'>
                                            <option value='active'" . ($user['status'] == 'active' ? ' selected' : '') . ">Active</option>
                                            <option value='inactive'" . ($user['status'] == 'inactive' ? ' selected' : '') . ">Inactive</option>
                                            <option value='deleted'" . ($user['status'] == 'deleted' ? ' selected' : '') . ">Deleted</option>
                                            </select>
                                            </div>
                                            <input type='hidden' name='user_id' value='" . htmlspecialchars($user['user_id']) . "'>
                                            <input type='submit' name='update_user' value='Update' class='button-update'>
                                            </form>
                                        </td>";
                                    echo "<td>" . htmlspecialchars($user['updated_at']) . "</td>";
                                    echo "<td>" . htmlspecialchars($user['created_at']) . "</td>";
                                    echo "<td>
                                            <form method='POST' action='' onsubmit=\"return confirm('Are you sure you want to delete this user?');\">
                                            <input type='hidden' name='user_id' value='" . htmlspecialchars($user['user_id']) . "'>
                                            <input type='submit' name='delete_user' value='Delete' class='button-delete'>
                                            </form>
                                        </td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No users found.</td></tr>";
                            }   
                        ?>
                    </tbody>
                    <style> 
                        .status-dropdown {
                            display: flex;          /* Use flexbox for alignment */
                            justify-content: center; /* Center the dropdown */
                            padding: 10px;
                        }   

                        .status-dropdown select {
                            padding: 10px;         /* Add some padding for better appearance */
                            border-radius: 4px;   /* Rounded corners */
                            border: 1px solid #ccc; /* Border style */
                            background-color: #fff; /* Background color */
                            font-size: 16px;      /* Font size for readability */
                        }
                    </style>
                </table>
            </div>
        </div>
    </div>

    <!-- Font Awesome -->
    <script defer src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="../admin_dashboard/js/common.js"></script>

</body>

</html>
