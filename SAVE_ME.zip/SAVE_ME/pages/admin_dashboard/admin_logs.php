<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();
if (!isset($_SESSION['email'])) {
    // Redirect to login page if the admin is not logged in
    header('Location: ../login.php?msg=Please login to continue');
    exit;
}

// Include database connection
require('../../configs/db.php');

// Fetch the admin data from the session or the database
$email = $_SESSION['email'];



// Initialize search variables
$searchName = isset($_GET['search_name']) ? $_GET['search_name'] : '';
$createdDate = isset($_GET['created_date']) ? $_GET['created_date'] : '';

// Prepare the SQL query with optional filters for name and date
$sql = "SELECT al.log_id, a.fullname, al.ip_address, al.admin_device, al.event_type, al.log_time
        FROM Admin_Logs al
        JOIN Admin a ON al.admin_id = a.admin_id
        WHERE a.fullname LIKE ? AND al.log_time LIKE ? ORDER BY al.log_time DESC";

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind parameters for search name and date
$searchNameParam = "%" . $searchName . "%";
$createdDateParam = "%" . $createdDate . "%";

// Execute the query with the search parameters
$stmt->bind_param("ss", $searchNameParam, $createdDateParam);
$stmt->execute();
$result = $stmt->get_result();

// Fetch the admin data
if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
    // Use htmlspecialchars to prevent XSS attacks
    $name = !empty($admin['fullname']) ? htmlspecialchars($admin['fullname']) : ''; 
} else { 
    // Redirect if no admin found
    header('Location: ../login.php?msg=Admin not found');
    exit;
}


// Close the statement
$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <title>Admin Dashboard | Admin Logs | Save ME</title>
 
    
    

    <!-- CSS Links -->
    <link href="./admin_dashboard/css/index/mainMobile.css" rel="stylesheet">
    <link href="./admin_dashboard/css/index/table.css" media="(min-width: 600px)" rel="stylesheet">
    <link href="./admin_dashboard/css/index/desktop.css" media="(min-width: 900px)" rel="stylesheet">
    <link rel="stylesheet" href="../admin_dashboard/css/common.css">
    <link rel="stylesheet" href="../admin_dashboard/css/admin_acc.css"> <!-- Link to your custom data grid CSS -->


 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>

    
</head>

<body>
    <div class="navbar-top">
       
        <div class="navbar-buttons">
            <button class="dropdown-btn"><img src="../img/user.png" alt="Profile" style="width: 20px; height: 20px;"></button>
            <!-- Add more buttons if needed -->
        </div>
    </div>

    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
        <img src="../img/saveme.png" alt="Logo" class="logo">
            <ul class="nav-links">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                   <i class="fas fa-tachometer-alt" style="margin-right: 8px;"></i><span>Dashboard</span>
                </a>
            </li>

                <!-- Monitor Users Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-screen"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Users</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="user_account.php">User Account</a></li>
                        <li><a href="user_logs.php">User Logs</a></li>
                     
                    </ul>
                </li>

                <!-- Monitor Admins Dropdown -->
                <li class="dropdown-btn">
                    <div class="dropdown-header">
                        <i class="fi fi-rr-display-code"></i>
                        <span class="dropdown-text" style="margin-right: 8px;">Monitor Admins</span>
                    </div>
                    <ul class="dropdown-content">
                    <li><a href="admin_account.php">Admin Account</a></li>
                        <li><a href="admin_logs.php">Admin Logs</a></li>
                       
                    </ul>
                </li>



                <li class="nav-item">
                    <a class="nav-link" href="announcements.php">
                    <i class="fi fi-rr-megaphone" style="margin-right: 8px;"></i><span>Announcements</span>
                    </a>
                </li>
            <li class="nav-item">
                <a class="nav-link" href="supports.php">
                <i class="fas fa-headset" style="margin-right: 8px;"></i><span>Support</span>
                </a>
            </li>
                <li class="nav-item">
                        <a class="nav-link" href="../../scripts/logout.php">
                            <i class="fas fa-sign-out-alt" style="margin-right: 8px;"></i><span>Log out</span>
                        </a>
                    </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="welcome-header">
                <h3>Welcome to Admin Accounts, <?php echo $name; ?></h3>
            </div>

            <div class="search-date">
            <form method="GET" action="">
    <label for="search_name">Search Name:</label>
    <input type="text" class="search-name" id="search_name" name="search_name" value="<?php echo htmlspecialchars($searchName); ?>" placeholder="Enter name...">

    <label for="created_date">Created Date:</label>
    <input type="date" class="search-date" id="created_date" name="created_date" value="<?php echo htmlspecialchars($createdDate); ?>">

    <input type="submit" value="Search" class="btn-search">
    <a href="admin_logs.php" class="btn-reset">Reset</a>
</form>

</div>



            <div class="data-grid">
    <table class="transaction-table">
        <thead>
            <tr>
             
            </tr>
        </thead>
        <tbody>
        <div class="data-grid">
    <table class="transaction-table">
        <thead>
            <tr>
                <th>Log ID</th>
                <th>Admin Name</th>
                <th>IP Address</th>
                <th>Device</th>
                <th>Event Type</th>
                <th>Log Time</th>
            </tr>
        </thead>
        <tbody>
        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['log_id']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['fullname']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['ip_address']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['admin_device']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['event_type']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['log_time']) . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>No logs found.</td></tr>";
                        }
                        ?>
        </tbody>
    </table>


  

    

</body>
</html>
