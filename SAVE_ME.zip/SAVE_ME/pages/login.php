<?php
session_start(); // Always start the session at the beginning of the page

// Check if the user is already logged in, redirect them if they are
if (isset($_SESSION['email'])) {
    // Check if it's an admin or a user and redirect accordingly
    if (isset($_SESSION['admin_id'])) {
        header('Location: admin_dashboard/index.php');
    } elseif (isset($_SESSION['user_id'])) {
        header('Location: user_dashboard/index.php');
    }
    exit;
}

// You can also check for any messages (e.g., from a failed login attempt or logout)
if (isset($_GET['msg'])) {
    echo '<p>' . htmlspecialchars($_GET['msg']) . '</p>';
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | SaveME</title>
    <link rel="icon" href="../assets/img/logo.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/logres.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>

<body class="body-color body-whole">

  

    <div class="container">
        <div class="row">
            <!-- Login Form Section -->
            <div class="col-lg-6 d-flex align-items-center justify-content-center" style="height: 100vh;">
                <div class="col-7">
                    <div class="text-center mb-5 d-block d-lg-none">
                        <a href="home.php"><img src="../assets/img/logo.png" height="80px"
                            class="zoom-on-hover" alt="logo"></a>
                    </div>
                    <div class="col-md-12 fw-bold mb-5 text-center login-header">WELCOME TO SAVE ME</div>
                    <form action="../scripts/login_auth.php" method="POST">
                        <div class="mb-2">
                            <label for="email" class="form-label text-black login-label">Email</label>
                            <input type="text" class="form-control  textfield" id="email"
                                name="email">
                            <small id="error-email" class="text-danger error-font"></small>
                        </div>
                        <div class="mb-5 password-field">
                            <label for="password" class="form-label text-black login-label">Password</label>
                            <input type="password" class="form-control textfield" id="password"
                                name="password">
                            <img src="../assets/img/eye-open.png" class="password-icon" id="eye-login">
                            <small id="error-password" class="mt-1 text-danger error-font">
                            </small>
                        </div>
                        <div class="text-center"><button type="submit" name="submit"
                                class="btn btn-primary  mb-4 elevatedButton">Login</button></div>
                    </form>
                    <p class="mt-4 login-label text-center">Don't have an account? <a href="register.php"
                            class="no-underline">Register</a></p>
                            <p class="mt-4 login-label text-center">Forgot password? <a href="forgotpass.php"
                            class="no-underline">Send OTP</a></p>
                    <!-- Social Icons -->
                    <div class="container mt-4">
                        <div class="row justify-content-center">
                            <div class="col-auto">
                                <a href="#">
                                    <img src="../assets/img/fb-icon.png" height="24px" class="zoom-on-hover"
                                        alt="facebook">
                                </a>
                            </div>
                            <div class="col-auto">
                                <a href="#">
                                    <img src="../assets/img/whats-icon.png" height="24px" class="zoom-on-hover"
                                        alt="whatsapp">
                                </a>
                            </div>
                            <div class="col-auto">
                                <a href="#">
                                    <img src="../assets/img/tel-icon.png" height="24px" class="zoom-on-hover"
                                        alt="telegram">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Hidden Logo Section -->
            <div class="col-lg-6 align-items-center justify-content-center pb-5 d-none d-lg-flex"
                style="height: 100vh; background-position: right;">
                <a href="../index.php"><img src="../assets/img/loginbg.png" class="zoom-on-hover" alt="Save Me Logo"></a> <!-- dito" -->
                <!-- Login Side Block -->
                <div class="login-block"></div>
            </div>
        </div>
    </div>

  


    <script src="../assets/js/login.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>

</html>