<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Save ME | BA-3101</title>
    <link rel="icon" href="../assets/img/logo.png" type="image/x-icon">

     <!-- Google Web Fonts -->
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link rel="stylesheet" href="lib/animate/animate.min.css"/>
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,500;0,700;1,400&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Poppins:wght@400;700&family=Volkhov:wght@400;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/home.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>

<body class="body-whole">

    

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-transparent pb-5">
        <div class="container">
            <a class="navbar-brand nav-logo" href="#">
                <img src="../assets/img/saveme.png" alt="" width="200"> <!-- LOGO"" -->
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class=""><i class="fas fa-bars fa-sm"></i></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link text-dark nav-change-color" href="#services">How it Works</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark nav-change-color" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark nav-change-color" href="#contact">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark nav-change-color" href="../pages/login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <div class="nav-signup-container">
                            <div class="nav-signup">
                                <a href="../pages/register.php" class="no-underline">Sign Up</a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Home Front Section  -->
    <section class="pt-3">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <p class="bank-subtitle mb-1">Personal Finance Goal Setter: Track Your Money Flow.</p>
                    <h2 class="mb-3 bank-title">Take Control of Your Finances Today! </h2>
                    <p class="bease-subtitle col-9 mb-4 bank-info">
                    Plan. Track. Save. Achieve your financial goals effortlessly with our all-in-one personal finance manager.<br>
                    </p>
                    <div class="row">
                        <div class="col-md-6 mb-5">
                            <a href="register.php"><button class="btn btn-primary border-0 bank-btn">Register now</button></a>
                        </div>
                        <ul class="list-inline">
                            <li class="list-inline-item bank-phone"> <img src="" 
                                    height="20px" class="zoom-on-hover"> +639326547891</li> <!-- picture ng call for contact"" -->
                            <li class="list-inline-item"><span class="vertical-divider"></span></li>
                            <li class="list-inline-item zoom-on-hover fa-sm"><a href="#"><i
                                        class="fab fa-facebook fa-lg" id="icon-awesome"></i></a></li>
                            <li class="list-inline-item zoom-on-hover fa-sm"><a href="#"><i
                                        class="fab fa-instagram fa-lg" id="icon-awesome"></i></a></li>
                            <li class="list-inline-item zoom-on-hover fa-sm"><a href="#"><i class="fab fa-twitter fa-lg"
                                        id="icon-awesome"></i></a></li>
                            <li class="list-inline-item zoom-on-hover fa-sm"><a href="#"><i
                                        class="fab fa-linkedin fa-lg" id="icon-awesome"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-7 d-none d-lg-block">
                    <img src="../assets/img/homepic.png" class=""> <!-- picture yung malaki sa right"" -->
                </div>
            </div>
        </div>
    </section>
    <div class="gap"></div>




    <!-- Our Services -->
    <section id="services">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mb-3">
                <h2 class="font-weight-bold section-title">How It Works</h2>
            </div>
        </div>
        <div class="row justify-content-center mb-5">
            <div class="col-12 col-md-8 text-center">
                <p class="section-subtitle">
                    Discover the features that make financial management simple and effective.
                </p>
            </div>
        </div>
        <div class="row justify-content-center text-center" id="service-list">
            <div class="col-7 col-md-2 mb-4">
                <div class="service-item">
                    <h5 class="service-title">Dashboard</h5>
                    <p class="service-description">Preview of your balance, savings, and recent transactions</p>
                </div>
            </div>
            
            <div class="col-7 col-md-2 mb-4">
                <div class="service-item">
                    <h5 class="service-title">Balance</h5>
                    <p class="service-description">Track your financial flow</p>
                </div>
            </div>
            
            <div class="col-7 col-md-2 mb-4">
                <div class="service-item">
                    <h5 class="service-title">Savings</h5>
                    <p class="service-description">Set and monitor your savings goals</p>
                </div>
            </div>
            
            <div class="col-7 col-md-2 mb-4">
                <div class="service-item">
                    <h5 class="service-title">Report and Analytics</h5>
                    <p class="service-description">Visualize your financial journey</p>
                </div>
            </div>
            
            <div class="col-7 col-md-2 mb-4">
                <div class="service-item">
                    <h5 class="service-title">Support</h5>
                    <p class="service-description">Connect with the admin</p>
                </div>
            </div>
            
            <div class="col-7 col-md-2 mb-4">
                <div class="service-item">
                    <h5 class="service-title">Schedule</h5>
                    <p class="service-description">Organize and list</p>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="gap"></div>




    <!-- We the Best -->
    <section id="about">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center best-subtitle">SAVE ME</div>
                <div class="col-12 text-center mb-5">
                    <h2 class="section-title">WE SAVE YOU ALWAYS</h2>
                </div>
            </div>
            <div class="row justify-content-center mt-3  ">
                <div class="col-lg-2 text-center mb-3">
                    <img src="../assets/img/set.jpg" height="200px" width="200px"  alt=""
                        class="img-fluid mb-3"> <!-- PIXXXXXX -->
                    <h3 class="best-title">Set Financial Goals</h3>
                    <p class="best-info">Create personal savings goals and set deadlines to keep your progress on track.</p>
                </div>
                <div class="col-lg-2 text-center mb-3">
                    <img src="../assets/img/track.jpg" height="200px" width="200px" alt=""
                        class="img-fluid mb-3"> <!-- PICTUREEEE -->
                    <h3 class="best-title">Track Your Transactions</h3>
                    <p class="best-info">Easily categorize income and expenses, and monitor your money flow.</p>
                </div>
                <div class="col-lg-2 text-center mb-3">
                    <img src="../assets/img/alerts.jpg"  height="200px" width="200px" alt=""
                        class="img-fluid mb-3"> <!-- D2222 -->
                    <h3 class="best-title">Real-Time Alerts and Insights</h3>
                    <p class="best-info">Receive helpful financial tips, alerts, and goal reminders to stay accountable. </p>
                </div>
                <div class="col-lg-2 text-center mb-3">
                    <img src="../assets/img/budget.jpg"  height="200px" width="200px" alt=""
                        class="img-fluid mb-3"> <!-- D2 pix -->
                    <h3 class="best-title">Budgeting Made Simple</h3>
                    <p class="best-info">Plan your Goals and monitor spending with detailed reports.</p>
                </div>
                <div class="col-lg-2 text-center mb-3">
                    <img src="../assets/img/goals.jpg" height="200px" width="200px" alt=""
                        class="img-fluid mb-3">  <!-- picccc -->
                    <h3 class="best-title">Reports and Analysis</h3>
                    <p class="best-info">Visualize your progress with insightful charts and financial overviews.</p>
                </div>
            </div>
        </div>
    </section>
    <div class="gap"></div>


    <!-- Budget Beasts -->
    <section id="beast">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <h2 class="beast-title mb-3">"Smart choices, big savings" <br>Make every peso count!</h2>
                    <p class="bease-subtitle mb-5">Unleash Your Inner Peace with Save ME
                    </p>
                    <div class="row">
                        <div class="col-md-4 mb-5 text-center">
                            <img src="../assets/img/Coins.png" height="100px" width="100px" alt=""
                                class="img-fluid"> <!-- PICCCC -->
                            <h3 class="image-title beast-info mt-3">Your money grow with us.
                            </h3>
                        </div>
                        <div class="col-md-4 mb-5 text-center">
                            <img src="../assets/img/Security.png" height="100px" width="100px" alt=""
                                class="img-fluid"> <!-- PICCCC -->
                            <h3 class="image-title beast-info mt-3">Where your money stays safe, and your peace of mind grows.</h3>
                        </div>
                        <div class="col-md-4 mb-5 text-center">
                            <img src="../assets/img/Bucket.png" height="100px" width="100px" alt=""
                                class="img-fluid"> <!-- oo -->
                            <h3 class="image-title beast-info mt-3">We make finance so lively, We keep your money</h3>
                        </div>
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="#"><i class="fab fa-facebook fa-lg"
                                        id="icon-awesome"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-instagram fa-lg"
                                        id="icon-awesome"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-twitter fa-lg"
                                        id="icon-awesome"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin fa-lg"
                                        id="icon-awesome"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="fab fa-youtube fa-lg"
                                        id="icon-awesome"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 d-none d-lg-block">
                    <img src="../assets/img/right2.png" alt="Image 4" class="img-fluid" style="margin-left: 120px">
                </div>
            </div>
        </div>
    </section>
    <div class="gap"></div>


    <!-- Result Years -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-3">
                    <h2 class="font-weight-bold section-title">BUDGET <br> TIPS</h2>
                </div>
            </div>
            <div class="row justify-content-center mb-5">
                <div class="col-12 col-md-6 text-center">
                    <p class="text-center section-subtitle">
                    These tips help control finances and achieve goals.
                    </p>
                </div>
            </div>
            <div class="row justify-content-center mt-5">
                <div class="row col-lg-9 text-center">
                    <div class="col-lg-3 text-center mb-4 text-rotate">
                        <h3 class="budget-title text-warning ">"Master Your Budget, Achieve Your Financial Goals."</h3>
                        <p class="budget-info"></p>
                    </div>
                    <div class="col-lg-3 text-center mb-4">
                        <h3 class="budget-title">Set Clear Financial Goals</h3>
                        <p class="budget-info">Set financial goals for<br>focused spending.</p>
                    </div>
                    <div class="col-lg-3 text-center mb-4">
                        <h3 class="budget-title">Follow the 50/30/20 Rule</h3>
                        <p class="budget-info">50% necessities, 30% wants, 20% savings,<br>stability.</p>
                    </div>
                    <div class="col-lg-3 text-center mb-4">
                        <h3 class="budget-title">Set Mini Goals</h3>
                        <p class="budget-info">Break goals into milestones and<br>celebrate achievements.</p>
                    </div>
                    <div class="col-lg-3 text-center mb-4">
                        <h3 class="budget-title">Track Your Progress</h3>
                        <p class="budget-info">Track finances and<br>stay accountable with reports.</p>
                    </div>
                    <div class="col-lg-3 text-center mb-4">
                        <h3 class="budget-title">Review and Adjust</h3>
                        <p class="budget-info">Regularly analyze budget reports <br> and adjust as needed.</p>
                    </div>
                    <div class="col-lg-3 text-center mb-4">
                        <h3 class="budget-title">Needs vs. Wants</h3>
                        <p class="budget-info">Differentiate necessities from<br>luxuries to prioritize spending.</p>
                    </div>
                    <div class="col-lg-3 text-center mb-4">
                        <h3 class="budget-title">Stay Flexible</h3>
                        <p class="budget-info">Adjust your budget and stay flexible always.</p>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div style="height: 100px;"></div>

    <!-- Our Team -->
<section id="team">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mb-3">
                <h2 class="font-weight-bold section-title">Our Team</h2>
            </div>
        </div>
        <div class="row justify-content-center text-center" id="team-list">
            <div class="col-6 col-md-4 mb-4">
                <a href="#">
                    <img src="../assets/img/team-member-1.jpg" alt="Team Member 1" class="img-fluid zoom-on-hover">
                </a>
                <h3 class="mt-3">Sheena Mae Arquillo</h3>
                <p>Backend Developer</p>
            </div>
            <div class="col-6 col-md-4 mb-4">
                <a href="#">
                    <img src="../assets/img/team-member-2.jpg" alt="Team Member 2" class="img-fluid zoom-on-hover">
                </a>
                <h3 class="mt-3">April Haziel Angeles</h3>
                <p>Project Manager/ Developer</p>
            </div>
            <div class="col-6 col-md-4 mb-4">
                <a href="#">
                    <img src="../assets/img/team-member-3.jpg" alt="Team Member 3" class="img-fluid zoom-on-hover">
                </a>
                <h3 class="mt-3">Kc Care</h3>
                <p>UI/UX Designer</p>
            </div>
        </div>
    </div>
</section>
<div class="gap"></div>



    <!-- Footer -->
    <footer id="contact">
        <div class="container pt-5 pb-3">
            <div class="row">
                <div class="col-lg-3">
                    <h5>About</h5>
                    <p>SAVE ME, founded by April, Sheena, and KC, empowers individuals to take control of their finances through innovative budgeting solutions. Join us on the journey to financial freedom!</p>
                    <ul class="list-inline">
                        <li class="list-inline-item"><a href="#"><i class="fab fa-facebook fa-lg"
                                    id="icon-awesome"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-instagram fa-lg"
                                    id="icon-awesome"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-twitter fa-lg"
                                    id="icon-awesome"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin fa-lg"
                                    id="icon-awesome"></i></a></li>
                    </ul>
                </div>
                <div class="col-lg-3">
                    <h5>How it works</h5>
                    <ul>
                        <li><a href="#">Sample Dashboard</a></li>
                        <li><a href="#">Balance Process</a></li>
                        <li><a href="#">Saving Process</a></li>
                        <li><a href="#">Report Analytics</a></li>
                        <li><a href="#">User Support</a></li>
                    </ul>
                </div>
                <div class="col-lg-3">
                    <h5>Information</h5>
                    <ul>
                        <li><a href="#">Project Manager</a></li>
                        <li><a href="#">IU/UX Designer</a></li>
                        <li><a href="#">Backend Developer</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Save Me</a></li>
                    </ul>
                </div>
                <div class="col-lg-3">
                    <h5>Support</h5>
                    <ul>
                        <li><a href="#">FAQs</a></li>
                        <li><a href="#">How it Works</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">SAVE ME</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <script src="../assets/js/bootstrap.min.js"></script>

</body>

</html>