<?php
session_start();

// Include the database connection file
include('../configs/db.php');

// Check if form is submitted
if (isset($_POST['submit'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    // First, check the Admin table
    $admin_sql = "SELECT * FROM Admin WHERE email = '$email' AND status = 'active'";
    $admin_result = $conn->query($admin_sql);

    if ($admin_result->num_rows > 0) {
        $admin = $admin_result->fetch_assoc();

        // Check if it's the test admin account
        if ($admin['email'] === 'test@sample.com' && $password === 'sample123') {
            // Set session variables for admin
            $_SESSION['email'] = $admin['email'];
            $_SESSION['admin_id'] = $admin['admin_id'];

            // Log the admin login event in Admin_Logs
            $log_sql = "INSERT INTO Admin_Logs (admin_id, ip_address, admin_device, event_type) 
                        VALUES (?, ?, ?, 'login')";
            $stmt = $conn->prepare($log_sql);
            $stmt->bind_param('iss', $admin['admin_id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
            $stmt->execute();

            header('Location: ../pages/admin_dashboard/index.php');
            exit;
        } elseif (password_verify($password, $admin['password'])) {
            // Set session variables for real admin accounts
            $_SESSION['email'] = $admin['email'];
            $_SESSION['admin_id'] = $admin['admin_id'];

            // Log the admin login event in Admin_Logs
            $log_sql = "INSERT INTO Admin_Logs (admin_id, ip_address, admin_device, event_type) 
                        VALUES (?, ?, ?, 'login')";
            $stmt = $conn->prepare($log_sql);
            $stmt->bind_param('iss', $admin['admin_id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
            $stmt->execute();

            header('Location: ../pages/admin_dashboard/index.php');
            exit;
        } else {
            header('Location: ../pages/login.php?msg=Invalid password');
            exit;
        }
    }

    // Next, check the User table if not an admin
    $user_sql = "SELECT * FROM User WHERE email = '$email' AND status = 'active'";
    $user_result = $conn->query($user_sql);

    if ($user_result->num_rows > 0) {
        $user = $user_result->fetch_assoc();

        // Check if it's the test user account
        if ($user['email'] === 'john.doe@example.com' && $password === 'sample123') {
            // Set session variables for normal user
            $_SESSION['email'] = $user['email'];
            $_SESSION['user_id'] = $user['user_id'];

            // Log the user login event in User_Logs
            $log_sql = "INSERT INTO User_Logs (user_id, ip_address, user_device, event_type) 
                        VALUES (?, ?, ?, 'login')";
            $stmt = $conn->prepare($log_sql);
            $stmt->bind_param('iss', $user['user_id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
            $stmt->execute();

            header('Location: ../pages/user_dashboard/index.php');
            exit;
        } elseif (password_verify($password, $user['password'])) {
            // Set session variables for real user accounts
            $_SESSION['email'] = $user['email'];
            $_SESSION['user_id'] = $user['user_id'];

            // Log the user login event in User_Logs
            $log_sql = "INSERT INTO User_Logs (user_id, ip_address, user_device, event_type) 
                        VALUES (?, ?, ?, 'login')";
            $stmt = $conn->prepare($log_sql);
            $stmt->bind_param('iss', $user['user_id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
            $stmt->execute();

            header('Location: ../pages/user_dashboard/index.php');
            exit;
        } else {
            header('Location: ../pages/login.php?msg=Invalid password');
            exit;
        }
    }

    // If neither user nor admin is found
    header('Location: ../pages/login.php?msg=User not found or inactive');
    exit;

    // Close the connection
    $conn->close();
}
?>
