-- User Table with soft delete and status column
CREATE TABLE User (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Store hashed passwords
    mobile_num VARCHAR(15), -- Allows handling of leading zeros
    balance DECIMAL(10, 2) DEFAULT 0.00,
    profile_picture VARCHAR(255) DEFAULT NULL, -- Profile picture field
    status ENUM('active', 'inactive', 'deleted') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME DEFAULT NULL, -- Added for soft delete
    INDEX (status) -- Index on status for faster queries
);

-- Insert row into User table
INSERT INTO User (name, email, password, mobile_num, balance, status) 
VALUES ('John Doe', 'john.doe@example.com', 'sample123', '0123456789', 5000.00, 'active');


-- Admin Table with soft delete and status column
CREATE TABLE Admin (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    fullname VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Store hashed passwords
    number VARCHAR(15), -- Consistent VARCHAR for phone numbers
    status ENUM('active', 'inactive', 'deleted') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME DEFAULT NULL,
    deleted_at DATETIME DEFAULT NULL, -- Soft delete timestamp
    INDEX (status) -- Index on status for faster queries
);

-- Insert rows into Admin table
INSERT INTO Admin (fullname, role, email, password, number, status) 
VALUES ('Alice Smith', 'Manager', 'alice.smith@example.com', 'hashedpassword456', '0987654321', 'active'),
       ('Test Admin', 'TEST', 'test@sample.com', 'sample123', '123156', 'active');

DELIMITER //

CREATE TRIGGER update_ended_at
BEFORE UPDATE ON Admin
FOR EACH ROW
BEGIN
    IF NEW.status IN ('inactive', 'deleted') AND OLD.status != NEW.status THEN
        SET NEW.ended_at = CURRENT_TIMESTAMP;
    ELSEIF NEW.status = 'active' THEN
        SET NEW.ended_at = NULL;
    END IF;
    
    IF NEW.status = 'deleted' AND OLD.status != 'deleted' THEN
        SET NEW.deleted_at = CURRENT_TIMESTAMP;
    END IF;
END//

DELIMITER ;


-- User Logs Table with foreign key to User
CREATE TABLE User_Logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,  -- Foreign key to User table
    ip_address VARCHAR(45),
    user_device VARCHAR(100),
    event_type ENUM('login', 'logout') NOT NULL,  -- Tracks login/logout events
    log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE SET NULL,
    INDEX (user_id)
);

-- Insert row into User_Logs table
INSERT INTO User_Logs (user_id, ip_address, user_device, event_type) 
VALUES (1, '192.168.1.1', 'Mozilla/5.0 (Windows NT 10.0)', 'login');


-- Admin Logs Table with foreign key to Admin
CREATE TABLE Admin_Logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    admin_id INT,  -- Foreign key to Admin table
    ip_address VARCHAR(45),
    admin_device VARCHAR(100),
    event_type ENUM('login', 'logout') NOT NULL,  -- Tracks login/logout events
    log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id) ON DELETE SET NULL,
    INDEX (admin_id)
);

-- Insert row into Admin_Logs table
INSERT INTO Admin_Logs (admin_id, ip_address, admin_device, event_type) 
VALUES (1, '192.168.1.1', 'Microsoft Edge/5.0 (Windows NT 10.0)', 'login');


-- Request Table for account deletion requests
CREATE TABLE Request (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,  -- Foreign key to User table
    time_request DATETIME DEFAULT CURRENT_TIMESTAMP,
    reason TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
    time_approved DATETIME DEFAULT NULL,
    admin_id INT,  -- Foreign key to Admin table
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE SET NULL,
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id) ON DELETE SET NULL,
    INDEX (user_id),
    INDEX (admin_id),
    INDEX (status)
);

-- Insert row into Request table
INSERT INTO Request (user_id, reason, status) 
VALUES (1, 'Need to update account details', 'pending');


-- Announcement Table with foreign key to Admin
CREATE TABLE Announcement (
    announcement_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(150) NOT NULL,
    content TEXT NOT NULL,
    announcement_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    admin_id INT,  -- Foreign key to Admin table
    FOREIGN KEY (admin_id) REFERENCES Admin(admin_id) ON DELETE SET NULL,
    INDEX (admin_id)
);

-- Insert row into Announcement table
INSERT INTO Announcement (title, content, admin_id) 
VALUES ('System Maintenance', 'The system will be down for maintenance on Friday.', 1);


-- Support Table with foreign key to User
CREATE TABLE Support (
    support_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,  -- Foreign key to User table
    concern TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    admin_reply TEXT,
    reply_at DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE SET NULL,
    INDEX (user_id)
);

-- Insert row into Support table
INSERT INTO Support (user_id, concern, admin_reply) 
VALUES (1, 'I cannot access my account.', 'Please reset your password.');


-- Savings Table with unique goal title, deadline, and status
CREATE TABLE Savings (
    saving_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,  -- Foreign key to User table
    title VARCHAR(100) NOT NULL UNIQUE, -- Unique goal title
    amount DECIMAL(10, 2) NOT NULL,
    description TEXT,
    deadline_date DATE NOT NULL,  -- Deadline for the savings goal
    status ENUM('in progress', 'completed') DEFAULT 'in progress',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE SET NULL,
    INDEX (user_id)
);

-- Insert row into Savings table
INSERT INTO Savings (user_id, title, amount, description, deadline_date) 
VALUES (1, 'Vacation Fund', 2000.00, 'Saving for a vacation trip', '2025-12-31');


-- Transaction Table with foreign key to User
CREATE TABLE Transaction (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,  -- Foreign key to User table
    amount DECIMAL(10, 2) NOT NULL,
    type ENUM('money in', 'money out') NOT NULL,
    description TEXT,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE SET NULL,
    INDEX (user_id)
);

-- Insert row into Transaction table
INSERT INTO Transaction (user_id, amount, type, description) 
VALUES (1, 1000.00, 'money out', 'Payment for utilities');


-- Savings_Transaction Table for tracking transactions related to savings goals
CREATE TABLE Savings_Transaction (
    savings_transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    saving_id INT,  -- Foreign key to Savings table
    user_id INT,    -- Foreign key to User table
    amount DECIMAL(10, 2) NOT NULL,
    type ENUM('add to savings', 'withdraw from savings') NOT NULL,
    description TEXT,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (saving_id) REFERENCES Savings(saving_id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE SET NULL,
    INDEX (saving_id),
    INDEX (user_id)
);

-- Insert rows into Savings_Transaction table
INSERT INTO Savings_Transaction (saving_id, user_id, amount, type, description)
VALUES (1, 1, 500.00, 'add to savings', 'Adding funds to vacation savings'),
       (1, 1, 200.00, 'withdraw from savings', 'Withdrew funds for vacation');
