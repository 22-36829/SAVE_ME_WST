<?php
// Database Connection
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$databasename = "bms";

// Create a connection
$conn = mysqli_connect($host, $dbusername, $dbpassword, $databasename);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
?>
